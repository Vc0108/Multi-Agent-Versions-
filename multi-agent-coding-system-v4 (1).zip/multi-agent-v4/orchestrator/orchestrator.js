// orchestrator/orchestrator.js — v4.0
const Orchestrator = {
  name:"Orchestrator", icon:"🎯",
  steps: [
    { id:1,  name:"Spec Generator",   icon:"📐", status:"pending" },
    { id:2,  name:"Planner",          icon:"🧭", status:"pending" },
    { id:3,  name:"Architect",        icon:"🏛️", status:"pending" },
    { id:4,  name:"Coder",            icon:"💻", status:"pending" },
    { id:5,  name:"Reviewer",         icon:"🔍", status:"pending" },
    { id:6,  name:"Database Agent",   icon:"🗄️", status:"pending" },
    { id:7,  name:"Tester",           icon:"🧪", status:"pending" },
    { id:8,  name:"Debugger",         icon:"🔧", status:"pending" },
    { id:9,  name:"Security Scanner", icon:"🔒", status:"pending" },
    { id:10, name:"Frontend Agent",   icon:"🎨", status:"pending" },
    { id:11, name:"DevOps Agent",     icon:"🐳", status:"pending" },
    { id:12, name:"Documenter",       icon:"📝", status:"pending" },
  ],

  onProgress:     null,
  onHumanReview:  null,  // callback → UI shows human approval modal
  humanApprovals: {},    // stores human decisions per agent

  // ── MAIN RUN ───────────────────────────────────────────────────────────────
  async run(taskInput) {
    Storage.clearAll();
    AgentEvaluator.clear();
    TaskHandoff.clear();
    this.humanApprovals = {};
    this.steps.forEach(s => s.status = "pending");
    Storage.appendLog({ agent:"Orchestrator", status:"pipeline_started", task:taskInput.task });

    const result = {
      task:taskInput, spec:null, planner:null, architect:null,
      coder:null, reviewer:null, database:null, tester:null,
      debugger:null, security:null, frontend:null, devops:null,
      documenter:null, specCompliance:null, evaluations:[], handoffs:[],
      audit_log:[], success:false
    };

    try {
      // ── STEP 1: SPEC GENERATOR ──────────────────────────────────────────
      this._updateStep(1,"running");
      TaskHandoff.record("User","Spec Generator",taskInput);
      const specResult = await SpecGeneratorAgent.run(taskInput);
      result.spec = specResult.data;
      const specEval = await AgentEvaluator.evaluate("Spec Generator", result.spec, taskInput.task);
      result.evaluations.push(specEval);
      this._updateStep(1,"awaiting_approval");
      await this._requestHumanApproval("Spec Generator", result.spec, specEval, 1);
      this._updateStep(1,"done");
      await sleep(2000);

      // ── STEP 2: PLANNER ─────────────────────────────────────────────────
      this._updateStep(2,"running");
      TaskHandoff.record("Spec Generator","Planner",result.spec);
      const plannerResult = await PlannerAgent.run(taskInput, result.spec);
      if (!plannerResult.success) throw new Error("Planner failed: "+plannerResult.error);
      result.planner = plannerResult.data;
      const plannerEval = await AgentEvaluator.evaluate("Planner", result.planner, taskInput.task);
      result.evaluations.push(plannerEval);
      this._updateStep(2,"awaiting_approval");
      await this._requestHumanApproval("Planner", result.planner, plannerEval, 2);
      this._updateStep(2,"done");
      await sleep(2000);

      // ── STEP 3: ARCHITECT ───────────────────────────────────────────────
      this._updateStep(3,"running");
      TaskHandoff.record("Planner","Architect",result.planner);
      const architectResult = await ArchitectAgent.run(result.spec, result.planner, taskInput);
      result.architect = architectResult.data;
      const archEval = await AgentEvaluator.evaluate("Architect", result.architect, taskInput.task);
      result.evaluations.push(archEval);
      this._updateStep(3,"awaiting_approval");
      await this._requestHumanApproval("Architect", result.architect, archEval, 3);
      this._updateStep(3,"done");
      await sleep(2000);

      // ── STEP 4: CODER (PARALLEL SUB-AGENTS) ────────────────────────────
      this._updateStep(4,"running");
      TaskHandoff.record("Architect","Coder",result.architect);
      const coderResult = await CoderAgent.run(result.planner, taskInput, result.spec, result.architect);
      if (!coderResult.success) throw new Error("Coder failed: "+coderResult.error);
      result.coder = coderResult.data;
      const coderEval = await AgentEvaluator.evaluate("Coder", (result.coder[0]&&result.coder[0].data)||{}, taskInput.task);
      result.evaluations.push(coderEval);
      this._updateStep(4,"awaiting_approval");
      await this._requestHumanApproval("Coder", result.coder, coderEval, 4);
      this._updateStep(4,"done");
      await sleep(2000);

      // ── STEP 5: REVIEWER (PARALLEL) ─────────────────────────────────────
      this._updateStep(5,"running");
      TaskHandoff.record("Coder","Reviewer",result.coder);
      const reviewerResult = await ReviewerAgent.run(coderResult.data, result.planner, taskInput, result.spec);
      if (!reviewerResult.success) throw new Error("Reviewer failed");
      result.reviewer = reviewerResult.data;
      const reviewEval = await AgentEvaluator.evaluate("Reviewer", (result.reviewer[0]&&result.reviewer[0].data)||{}, taskInput.task);
      result.evaluations.push(reviewEval);
      this._updateStep(5,"awaiting_approval");
      await this._requestHumanApproval("Reviewer", result.reviewer, reviewEval, 5);
      this._updateStep(5,"done");
      await sleep(2000);

      // ── STEP 6: DATABASE AGENT (NEW) ────────────────────────────────────
      this._updateStep(6,"running");
      TaskHandoff.record("Reviewer","Database Agent",result.reviewer);
      const dbResult = await DatabaseAgent.run(result.spec, taskInput);
      result.database = dbResult.data;
      const dbEval = await AgentEvaluator.evaluate("Database Agent", result.database, taskInput.task);
      result.evaluations.push(dbEval);
      this._updateStep(6,"awaiting_approval");
      await this._requestHumanApproval("Database Agent", result.database, dbEval, 6);
      this._updateStep(6,"done");
      await sleep(2000);

      // ── STEP 7: TESTER ──────────────────────────────────────────────────
      this._updateStep(7,"running");
      TaskHandoff.record("Database Agent","Tester",result.database);
      const testerResult = await TesterAgent.run(result.reviewer, taskInput);
      if (!testerResult.success) throw new Error("Tester failed");
      result.tester = testerResult.data;
      const testerEval = await AgentEvaluator.evaluate("Tester", (result.tester[0]&&result.tester[0].data)||{}, taskInput.task);
      result.evaluations.push(testerEval);
      this._updateStep(7,"awaiting_approval");
      await this._requestHumanApproval("Tester", result.tester, testerEval, 7);
      this._updateStep(7,"done");
      await sleep(2000);

      // ── STEP 8: DEBUGGER ────────────────────────────────────────────────
      const needsDebug = result.tester.some(r=>r.data&&r.data.needs_debug);
      this._updateStep(8, needsDebug?"running":"skipped");
      TaskHandoff.record("Tester","Debugger",result.tester);
      const debuggerResult = await DebuggerAgent.run(result.tester, taskInput);
      result.debugger = debuggerResult.data;
      if (needsDebug && result.debugger?.length) {
        const debugEval = await AgentEvaluator.evaluate("Debugger", (result.debugger[0]&&result.debugger[0].data)||{}, taskInput.task);
        result.evaluations.push(debugEval);
      }
      this._updateStep(8,"done");
      await sleep(2000);

      // ── STEP 9: SECURITY SCANNER ─────────────────────────────────────────
      this._updateStep(9,"running");
      const codeForScan = (result.debugger&&result.debugger.length>0) ? result.debugger : result.tester;
      TaskHandoff.record("Debugger","Security Scanner",codeForScan);
      const secResult = await SecurityScannerAgent.run(codeForScan, taskInput);
      result.security = secResult.data;
      const secEval = await AgentEvaluator.evaluate("Security Scanner", result.security, taskInput.task);
      result.evaluations.push(secEval);
      this._updateStep(9,"awaiting_approval");
      await this._requestHumanApproval("Security Scanner", result.security, secEval, 9);
      this._updateStep(9,"done");
      await sleep(2000);

      // ── STEP 10: FRONTEND AGENT (NEW) ────────────────────────────────────
      this._updateStep(10,"running");
      const finalCode = (result.debugger&&result.debugger.length>0) ? result.debugger : result.tester;
      TaskHandoff.record("Security Scanner","Frontend Agent",result.security);
      const frontendResult = await FrontendAgent.run(result.spec, taskInput, finalCode);
      result.frontend = frontendResult.data;
      const frontendEval = await AgentEvaluator.evaluate("Frontend Agent", result.frontend, taskInput.task);
      result.evaluations.push(frontendEval);
      this._updateStep(10,"awaiting_approval");
      await this._requestHumanApproval("Frontend Agent", result.frontend, frontendEval, 10);
      this._updateStep(10,"done");
      await sleep(2000);

      // ── STEP 11: DEVOPS AGENT (NEW) ──────────────────────────────────────
      this._updateStep(11,"running");
      TaskHandoff.record("Frontend Agent","DevOps Agent",result.frontend);
      const devopsResult = await DevOpsAgent.run(taskInput, result.spec);
      result.devops = devopsResult.data;
      const devopsEval = await AgentEvaluator.evaluate("DevOps Agent", result.devops, taskInput.task);
      result.evaluations.push(devopsEval);
      this._updateStep(11,"awaiting_approval");
      await this._requestHumanApproval("DevOps Agent", result.devops, devopsEval, 11);
      this._updateStep(11,"done");
      await sleep(2000);

      // ── STEP 12: DOCUMENTER ──────────────────────────────────────────────
      this._updateStep(12,"running");
      const docInput = (result.debugger&&result.debugger.length>0) ? result.debugger : result.tester;
      TaskHandoff.record("DevOps Agent","Documenter",result.devops);
      const documenterResult = await DocumenterAgent.run(docInput, result.planner, taskInput, result.spec);
      if (!documenterResult.success) throw new Error("Documenter failed");
      result.documenter = documenterResult.data;
      const docEval = await AgentEvaluator.evaluate("Documenter", result.documenter, taskInput.task);
      result.evaluations.push(docEval);
      this._updateStep(12,"done");

      // ── POST PIPELINE ─────────────────────────────────────────────────────
      const allCode = (result.coder||[]).filter(r=>r.success&&r.data?.code).map(r=>r.data.code).join("\n");
      result.specCompliance = ContextBuilder.specValidator(result.spec, allCode);
      try { AgentMemory.saveRun(result); } catch(e) {}

      result.handoffs  = TaskHandoff.getChain();
      result.audit_log = Storage.getLogs();
      result.success   = true;
      Storage.appendLog({ agent:"Orchestrator", status:"pipeline_completed" });
      return result;

    } catch(error) {
      Storage.appendLog({ agent:"Orchestrator", status:"pipeline_error", error:error.message });
      result.audit_log = Storage.getLogs();
      result.error     = error.message;
      return result;
    }
  },

  // ── HUMAN APPROVAL GATE ────────────────────────────────────────────────────
  async _requestHumanApproval(agentName, output, evaluation, stepId) {
    if (!this.onHumanReview) return; // skip if no UI callback set

    return new Promise((resolve) => {
      this.onHumanReview({
        agentName, output, evaluation, stepId,
        onApprove: (humanScore, feedback) => {
          const humanEval = AgentEvaluator.buildHumanEval(agentName, humanScore, feedback, true);
          this.humanApprovals[agentName] = { approved:true, score:humanScore, feedback };
          TaskHandoff.approve(stepId);
          Storage.appendLog({ agent:agentName, status:"human_approved", score:humanScore });
          resolve({ approved:true });
        },
        onReject: (feedback) => {
          this.humanApprovals[agentName] = { approved:false, feedback };
          Storage.appendLog({ agent:agentName, status:"human_rejected", feedback });
          resolve({ approved:false, feedback });
        },
        onSkip: () => {
          Storage.appendLog({ agent:agentName, status:"human_skipped" });
          resolve({ approved:true, skipped:true });
        }
      });
    });
  },

  _updateStep(id, status) {
    const step = this.steps.find(s=>s.id===id);
    if (step) step.status = status;
    if (this.onProgress) this.onProgress(id, status);
  }
};
