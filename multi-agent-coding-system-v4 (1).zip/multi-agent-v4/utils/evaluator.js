// utils/evaluator.js — v4.0
// Human 50% + AI 50% evaluation system

const AgentEvaluator = {
  evaluations: [],

  CRITERIA: {
    "Spec Generator": {
      checks: [
        { key:"has_endpoints",    label:"Has endpoint definitions",   fn:(d)=>Array.isArray(d.endpoints)&&d.endpoints.length>=2 },
        { key:"has_data_models",  label:"Has data model definitions", fn:(d)=>Array.isArray(d.data_models)&&d.data_models.length>=1 },
        { key:"has_business_rules",label:"Has business rules",        fn:(d)=>Array.isArray(d.business_rules)&&d.business_rules.length>=1 },
        { key:"has_auth_type",    label:"Auth type specified",        fn:(d)=>!!d.auth_type },
        { key:"has_features",     label:"Feature list present",       fn:(d)=>Array.isArray(d.features)&&d.features.length>=1 },
      ]
    },
    "Planner": {
      checks: [
        { key:"has_summary",      label:"Project summary present",    fn:(d)=>!!d.project_summary&&d.project_summary.length>10 },
        { key:"has_subtasks",     label:"Subtasks defined",           fn:(d)=>Array.isArray(d.subtasks)&&d.subtasks.length>=2 },
        { key:"subtasks_complete",label:"Subtasks have all fields",   fn:(d)=>(d.subtasks||[]).every(t=>t.id&&t.name&&t.description&&t.deliverable) },
        { key:"has_tech_stack",   label:"Tech stack specified",       fn:(d)=>!!d.tech_stack },
        { key:"has_priorities",   label:"Priorities assigned",        fn:(d)=>(d.subtasks||[]).every(t=>t.priority) },
      ]
    },
    "Architect": {
      checks: [
        { key:"has_components",     label:"Components defined",          fn:(d)=>Array.isArray(d.components)&&d.components.length>=1 },
        { key:"has_file_structure", label:"File structure planned",      fn:(d)=>Array.isArray(d.file_structure)&&d.file_structure.length>=1 },
        { key:"has_guidelines",     label:"Coding guidelines set",       fn:(d)=>Array.isArray(d.coding_guidelines)&&d.coding_guidelines.length>=1 },
        { key:"has_security",       label:"Security considerations",     fn:(d)=>Array.isArray(d.security_considerations)&&d.security_considerations.length>=1 },
        { key:"has_data_flow",      label:"Data flow described",         fn:(d)=>!!d.data_flow },
      ]
    },
    "Coder": {
      checks: [
        { key:"has_code",          label:"Code is present",             fn:(d)=>!!d.code&&d.code.length>100 },
        { key:"no_placeholders",   label:"No placeholder code",         fn:(d)=>!/(TODO|not provided|implement this|placeholder|coming soon)/i.test(d.code||"") },
        { key:"has_imports",       label:"Has import statements",       fn:(d)=>/import |from |require\(/i.test(d.code||"") },
        { key:"has_functions",     label:"Has function definitions",    fn:(d)=>/def |function |async def |async function/i.test(d.code||"") },
        { key:"has_error_handling",label:"Has error handling",          fn:(d)=>/try:|except |try {|catch |HTTPException/i.test(d.code||"") },
      ]
    },
    "Reviewer": {
      checks: [
        { key:"has_verdict",       label:"Verdict is present",          fn:(d)=>d.verdict==="PASS"||d.verdict==="FAIL" },
        { key:"has_score",         label:"Score is numeric",            fn:(d)=>typeof d.score==="number"&&d.score>=0&&d.score<=100 },
        { key:"has_issues_list",   label:"Issues list defined",         fn:(d)=>Array.isArray(d.issues) },
        { key:"has_strengths",     label:"Strengths listed",            fn:(d)=>Array.isArray(d.strengths)&&d.strengths.length>=1 },
        { key:"has_revised_code",  label:"Revised code given",          fn:(d)=>typeof d.revised_code==="string" },
      ]
    },
    "Tester": {
      checks: [
        { key:"has_test_cases",    label:"Test cases defined",          fn:(d)=>Array.isArray(d.test_cases)&&d.test_cases.length>=1 },
        { key:"has_test_code",     label:"Test code generated",         fn:(d)=>!!d.test_code&&d.test_code.length>50 },
        { key:"test_types_varied", label:"Multiple test types",         fn:(d)=>new Set((d.test_cases||[]).map(t=>t.type)).size>=2 },
        { key:"has_needs_debug",   label:"Debug flag set",              fn:(d)=>typeof d.needs_debug==="boolean" },
        { key:"tests_have_status", label:"Test cases have status",      fn:(d)=>(d.test_cases||[]).every(t=>t.status) },
      ]
    },
    "Debugger": {
      checks: [
        { key:"has_fixed_code",    label:"Fixed code present",          fn:(d)=>!!d.fixed_code&&d.fixed_code.length>50 },
        { key:"has_root_cause",    label:"Root cause identified",       fn:(d)=>!!d.root_cause&&d.root_cause.length>10 },
        { key:"has_fix_applied",   label:"Fix description given",       fn:(d)=>!!d.fix_applied },
        { key:"has_confidence",    label:"Confidence level stated",     fn:(d)=>!!d.confidence },
        { key:"no_placeholders",   label:"No placeholder in fixed code",fn:(d)=>!/(TODO|placeholder|not implemented)/i.test(d.fixed_code||"") },
      ]
    },
    "Security Scanner": {
      checks: [
        { key:"has_findings",      label:"Findings array present",      fn:(d)=>Array.isArray(d.findings) },
        { key:"has_risk_level",    label:"Overall risk level set",      fn:(d)=>["none","low","medium","high","critical"].includes(d.overall_risk) },
        { key:"has_file_count",    label:"Files scanned count",         fn:(d)=>typeof d.files_scanned==="number" },
        { key:"findings_have_ids", label:"Findings have SEC IDs",       fn:(d)=>(d.findings||[]).every(f=>f.id) },
        { key:"has_total_count",   label:"Total findings count",        fn:(d)=>typeof d.total_findings==="number" },
      ]
    },
    "Frontend Agent": {
      checks: [
        { key:"has_html",         label:"HTML file present",            fn:(d)=>!!d.html&&d.html.length>100 },
        { key:"has_css",          label:"CSS styles present",           fn:(d)=>!!d.css&&d.css.length>50 },
        { key:"has_js",           label:"JavaScript present",           fn:(d)=>!!d.js&&d.js.length>100 },
        { key:"has_api_calls",    label:"API calls implemented",        fn:(d)=>/fetch\(|axios\./i.test(d.js||"") },
        { key:"has_auth_ui",      label:"Auth UI present",              fn:(d)=>/login|register|signin/i.test(d.html||"") },
      ]
    },
    "Database Agent": {
      checks: [
        { key:"has_schema",       label:"Schema SQL present",           fn:(d)=>!!d.schema&&d.schema.length>50 },
        { key:"has_migration",    label:"Migration file present",       fn:(d)=>!!d.migration&&d.migration.length>50 },
        { key:"has_seed",         label:"Seed data present",            fn:(d)=>!!d.seed_data&&d.seed_data.length>20 },
        { key:"has_indexes",      label:"Indexes defined",              fn:(d)=>/INDEX|index/i.test(d.schema||"") },
        { key:"has_constraints",  label:"Constraints defined",          fn:(d)=>/NOT NULL|PRIMARY KEY|FOREIGN KEY/i.test(d.schema||"") },
      ]
    },
    "DevOps Agent": {
      checks: [
        { key:"has_dockerfile",   label:"Dockerfile present",           fn:(d)=>!!d.dockerfile&&d.dockerfile.length>50 },
        { key:"has_compose",      label:"docker-compose present",       fn:(d)=>!!d.docker_compose&&d.docker_compose.length>50 },
        { key:"has_ci_cd",        label:"CI/CD workflow present",       fn:(d)=>!!d.ci_cd&&d.ci_cd.length>50 },
        { key:"has_env_example",  label:".env.example complete",        fn:(d)=>!!d.env_example&&d.env_example.length>20 },
        { key:"has_setup_script", label:"Setup script present",         fn:(d)=>!!d.setup_script&&d.setup_script.length>20 },
      ]
    },
    "Documenter": {
      checks: [
        { key:"has_readme",        label:"README is present",           fn:(d)=>!!d.readme&&d.readme.length>100 },
        { key:"has_api_reference", label:"API reference present",       fn:(d)=>!!d.api_reference&&d.api_reference.length>50 },
        { key:"has_setup_guide",   label:"Setup guide present",         fn:(d)=>!!d.setup_guide&&d.setup_guide.length>50 },
        { key:"has_architecture",  label:"Architecture overview",       fn:(d)=>!!d.architecture_overview },
        { key:"has_functions",     label:"Functions documented",        fn:(d)=>Array.isArray(d.functions_documented) },
      ]
    }
  },

  // ── LOCAL EVALUATION (AI 25%) ─────────────────────────────────────────────
  evaluateLocally(agentName, outputData) {
    const criteria = this.CRITERIA[agentName];
    if (!criteria) return { score:100, passed:true, checks:[], method:"local" };
    const results = criteria.checks.map(check => {
      let passed = false;
      try { passed = check.fn(outputData); } catch(e) { passed = false; }
      return { key:check.key, label:check.label, passed };
    });
    const score = Math.round((results.filter(r=>r.passed).length / results.length) * 100);
    return { agent:agentName, score, passed:score>=60, checks:results, method:"local",
      timestamp:new Date().toISOString(),
      recommendation: score>=60 ? "Output meets quality requirements." : `Failed ${results.filter(r=>!r.passed).length} checks.` };
  },

  // ── GEMINI EVALUATION (AI 25%) ────────────────────────────────────────────
  async evaluateWithGemini(agentName, outputData, taskDescription) {
    const apiKey = Storage.getGeminiKey ? Storage.getGeminiKey() : null;
    if (!apiKey) return null;
    let outputSnippet = "";
    try { outputSnippet = JSON.stringify(outputData,null,2).substring(0,1500).replace(/[\u0000-\u001F\u007F]/g," "); }
    catch(e) { outputSnippet = String(outputData).substring(0,1500); }
    const safeTask = String(taskDescription||"").replace(/[`"]/g,"'").substring(0,200);
    const promptText = [
      "You are an independent code quality evaluator.",
      "Agent: " + agentName, "Task: " + safeTask, "",
      "OUTPUT:", outputSnippet, "",
      "Evaluate strictly. Respond ONLY with valid JSON:",
      '{"score":85,"passed":true,"strengths":["strength"],"weaknesses":["weakness"],"recommendation":"One sentence."}'
    ].join("\n");
    try {
      const url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=" + apiKey;
      const response = await fetch(url, {
        method:"POST", headers:{"Content-Type":"application/json"},
        body: JSON.stringify({ contents:[{role:"user",parts:[{text:promptText}]}],
          generationConfig:{temperature:0.2,maxOutputTokens:512,responseMimeType:"application/json"} })
      });
      if (!response.ok) return null;
      const data = await response.json();
      const text = data?.candidates?.[0]?.content?.parts?.[0]?.text||"";
      if (!text) return null;
      const parsed = JSON.parse(text.replace(/```json|```/g,"").trim());
      return { agent:agentName, score:parsed.score||0, passed:parsed.passed!==false,
        strengths:parsed.strengths||[], weaknesses:parsed.weaknesses||[],
        recommendation:parsed.recommendation||"", method:"gemini-2.0-flash",
        timestamp:new Date().toISOString() };
    } catch(e) { return null; }
  },

  // ── HUMAN EVALUATION (50%) ────────────────────────────────────────────────
  // Called from UI after human submits their score
  buildHumanEval(agentName, humanScore, humanFeedback, approved) {
    return {
      agent: agentName, score: humanScore, passed: approved,
      feedback: humanFeedback, method: "human",
      timestamp: new Date().toISOString()
    };
  },

  // ── COMBINED: Local 25% + Gemini 25% + Human 50% ─────────────────────────
  async evaluate(agentName, outputData, taskDescription, humanEval=null) {
    const localResult  = this.evaluateLocally(agentName, outputData);
    const geminiResult = await this.evaluateWithGemini(agentName, outputData, taskDescription);

    let finalScore, finalPassed;
    if (humanEval) {
      // Full formula: local 25% + gemini 25% + human 50%
      const aiScore = geminiResult
        ? Math.round(localResult.score * 0.5 + geminiResult.score * 0.5)
        : localResult.score;
      finalScore  = Math.round(aiScore * 0.5 + humanEval.score * 0.5);
      finalPassed = humanEval.passed;
    } else {
      // No human yet — AI only (local 40% + gemini 60%)
      finalScore  = geminiResult
        ? Math.round(localResult.score * 0.4 + geminiResult.score * 0.6)
        : localResult.score;
      finalPassed = finalScore >= 60;
    }

    const evaluation = {
      agent:agentName, final_score:finalScore, final_passed:finalPassed,
      local_evaluation:localResult, gemini_evaluation:geminiResult,
      human_evaluation:humanEval, dual_evaluation:!!geminiResult,
      human_reviewed:!!humanEval, timestamp:new Date().toISOString()
    };
    this.evaluations.push(evaluation);
    Storage.appendLog({ agent:agentName, status:"evaluated", score:finalScore,
      passed:finalPassed, human_reviewed:!!humanEval });
    return evaluation;
  },

  getAll()    { return this.evaluations; },
  getFor(n)   { return this.evaluations.filter(e=>e.agent===n); },
  clear()     { this.evaluations = []; }
};
