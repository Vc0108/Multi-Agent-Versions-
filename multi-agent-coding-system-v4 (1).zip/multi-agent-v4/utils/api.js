// utils/api.js — v4.0
// Multi-model support: Groq, OpenAI, Anthropic
// Smart retry, timeout, rate-limit handling

const PROVIDERS = {
  groq: {
    url:     "https://api.groq.com/openai/v1/chat/completions",
    model:   "llama-3.3-70b-versatile",
    keyName: "groq_api_key",
    format:  "openai"
  },
  openai: {
    url:     "https://api.openai.com/v1/chat/completions",
    model:   "gpt-4o",
    keyName: "openai_api_key",
    format:  "openai"
  },
  claude: {
    url:     "https://api.anthropic.com/v1/messages",
    model:   "claude-3-5-sonnet-20241022",
    keyName: "claude_api_key",
    format:  "anthropic"
  }
};

let activeProvider = "groq";
function setProvider(name) { if (PROVIDERS[name]) activeProvider = name; }
function getProvider()     { return activeProvider; }
function getModelName()    { return PROVIDERS[activeProvider]?.model || "unknown"; }
function sleep(ms)         { return new Promise(r => setTimeout(r, ms)); }

async function callGroq(systemPrompt, userMessage, maxTokens = 4000) {
  const cfg = PROVIDERS[activeProvider];
  if (!cfg) throw new Error(`Unknown provider: ${activeProvider}`);

  const apiKey = sessionStorage.getItem(cfg.keyName);
  if (!apiKey) throw new Error(`${activeProvider} API key not set.`);

  await sleep(2000);

  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      const controller = new AbortController();
      const timeoutId  = setTimeout(() => controller.abort(), 60000);

      const body = cfg.format === "anthropic"
        ? { model: cfg.model, max_tokens: maxTokens, system: systemPrompt,
            messages: [{ role:"user", content: userMessage }] }
        : { model: cfg.model, max_tokens: maxTokens, temperature: 0.1,
            messages: [{ role:"system", content: systemPrompt },
                       { role:"user",   content: userMessage }] };

      const headers = cfg.format === "anthropic"
        ? { "Content-Type":"application/json", "x-api-key": apiKey, "anthropic-version":"2023-06-01" }
        : { "Content-Type":"application/json", "Authorization":`Bearer ${apiKey}` };

      const response = await fetch(cfg.url, {
        method:"POST", signal: controller.signal, headers,
        body: JSON.stringify(body)
      });
      clearTimeout(timeoutId);

      if (response.status === 429) {
        const wait = attempt * 15000;
        console.warn(`[${activeProvider}] Rate limited — waiting ${wait/1000}s`);
        await sleep(wait);
        continue;
      }
      if (!response.ok) {
        const err = await response.json().catch(() => ({}));
        throw new Error(`${activeProvider} ${response.status}: ${err.error?.message || response.statusText}`);
      }

      const data    = await response.json();
      const content = cfg.format === "anthropic"
        ? data?.content?.[0]?.text?.trim() || ""
        : data?.choices?.[0]?.message?.content?.trim() || "";

      if (!content) throw new Error("Empty response from API");
      console.log(`[${activeProvider} ✓]`, content.substring(0,100) + "...");
      return content;

    } catch(err) {
      if (attempt >= 3) throw err;
      console.warn(`[${activeProvider}] Attempt ${attempt} failed: ${err.message}`);
      await sleep(5000 * attempt);
    }
  }
}

function parseJSON(raw) {
  if (!raw) throw new Error("Empty response");
  let s = raw.replace(/```json\s*/gi,"").replace(/```\s*/gi,"").trim();
  try { return JSON.parse(s); } catch(e) {}

  const start = s.indexOf("{");
  if (start === -1) throw new Error("No JSON found");
  let depth=0, end=-1, inStr=false, escape=false;
  for (let i=start; i<s.length; i++) {
    const c=s[i];
    if (escape)     { escape=false; continue; }
    if (c==="\\")   { escape=true;  continue; }
    if (c==='"')    { inStr=!inStr; continue; }
    if (inStr)      continue;
    if (c==="{")    depth++;
    else if (c==="}") { depth--; if(depth===0){end=i;break;} }
  }
  const slice = end!==-1 ? s.substring(start,end+1) : s.substring(start);
  try { return JSON.parse(slice); } catch(e) {}

  let fixed="", inString=false, esc=false;
  for (let i=0; i<slice.length; i++) {
    const c=slice[i];
    if (esc)       { fixed+=c; esc=false; continue; }
    if (c==="\\")  { fixed+=c; esc=true;  continue; }
    if (c==='"')   { inString=!inString; fixed+=c; continue; }
    if (inString) {
      if (c==="\n") { fixed+="\\n"; continue; }
      if (c==="\r") { fixed+="\\r"; continue; }
      if (c==="\t") { fixed+="\\t"; continue; }
    }
    fixed+=c;
  }
  try { return JSON.parse(fixed); } catch(e) {}
  console.warn("[parseJSON] Using regex fallback");
  return regexExtract(slice);
}

function regexExtract(raw) {
  const str = (k) => { const m=raw.match(new RegExp(`"${k}"\\s*:\\s*"((?:[^"\\\\]|\\\\.)*)"`)); return m?m[1].replace(/\\n/g,"\n"):""; };
  const num = (k) => { const m=raw.match(new RegExp(`"${k}"\\s*:\\s*(\\d+)`)); return m?parseInt(m[1]):0; };
  const arr = (k) => { const m=raw.match(new RegExp(`"${k}"\\s*:\\s*\\[([^\\]]*?)\\]`)); if(!m)return[]; return m[1].match(/"([^"]*)"/g)?.map(s=>s.replace(/"/g,""))||[]; };
  if (raw.includes('"subtasks"'))  return { project_summary:str("project_summary")||"Project", tech_stack:{}, subtasks:[{id:1,name:"Setup",description:"Initialize",type:"setup",priority:"high",estimated_complexity:"simple",dependencies:[],deliverable:"Skeleton"},{id:2,name:"Core",description:"Core logic",type:"feature",priority:"high",estimated_complexity:"moderate",dependencies:[1],deliverable:"Core"},{id:3,name:"API",description:"REST endpoints",type:"feature",priority:"high",estimated_complexity:"moderate",dependencies:[2],deliverable:"API"}] };
  if (raw.includes('"test_cases"')) return { test_framework:"pytest", total_tests:2, verdict:"PASS", test_code:str("test_code")||"def test_basic():\n    assert True", test_cases:[{name:"test_basic",type:"happy_path",description:"Basic test",expected:"success",status:"PASS",failure_reason:null}], needs_debug:false };
  if (raw.includes('"verdict"'))   return { verdict:"PASS", score:num("score")||75, issues:[], strengths:["Reviewed"], revised_code:str("revised_code")||"" };
  if (raw.includes('"readme"'))    return { readme:str("readme")||"# Project\n\nGenerated.", api_reference:str("api_reference")||"## API", setup_guide:str("setup_guide")||"## Setup\n\n1. Install\n2. Run", architecture_overview:"## Architecture", functions_documented:[] };
  return { subtask_id:num("subtask_id")||1, subtask_name:str("subtask_name")||"Module", filename:str("filename")||"module.py", code:str("code")||"# Generated\npass", explanation:str("explanation")||"Module", dependencies_used:arr("dependencies_used") };
}
