// utils/memory.js — v4.0
const AgentMemory = {
  saveRun(result) {
    try {
      const lessons = [];
      (result.reviewer||[]).forEach(r => {
        if (r.success&&r.data?.issues?.length) {
          r.data.issues.forEach(i => lessons.push(`REVIEWER: ${i.description||i}`));
        }
      });
      if (result.security?.findings?.length) {
        result.security.findings.forEach(f => lessons.push(`SECURITY: ${f.description||f.pattern}`));
      }
      const existing = JSON.parse(localStorage.getItem("agent_memory_v4")||"[]");
      const updated  = [...existing, ...lessons].slice(-50);
      localStorage.setItem("agent_memory_v4", JSON.stringify(updated));
    } catch(e) {}
  },
  getContextForAgent(agentName, task) {
    try {
      const lessons = JSON.parse(localStorage.getItem("agent_memory_v4")||"[]");
      if (!lessons.length) return "";
      return `\n[MEMORY FROM PAST RUNS — avoid repeating these mistakes]\n${lessons.slice(-10).join("\n")}\n`;
    } catch(e) { return ""; }
  },
  clear() { try { localStorage.removeItem("agent_memory_v4"); } catch(e) {} }
};
