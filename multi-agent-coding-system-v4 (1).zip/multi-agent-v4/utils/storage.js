// utils/storage.js — v4.0
const Storage = {
  save(key, data)   { try { sessionStorage.setItem(key, JSON.stringify(data)); } catch(e) {} },
  load(key, def=null) { try { const r=sessionStorage.getItem(key); return r?JSON.parse(r):def; } catch(e) { return def; } },
  remove(key)       { sessionStorage.removeItem(key); },

  saveApiKey(k)     { sessionStorage.setItem("groq_api_key",   k); },
  getApiKey()       { return sessionStorage.getItem("groq_api_key"); },
  saveGeminiKey(k)  { sessionStorage.setItem("gemini_api_key", k); },
  getGeminiKey()    { return sessionStorage.getItem("gemini_api_key"); },
  saveOpenAIKey(k)  { sessionStorage.setItem("openai_api_key", k); },
  getOpenAIKey()    { return sessionStorage.getItem("openai_api_key"); },

  appendLog(entry) {
    const logs = this.load("mas_logs_v4", []);
    logs.push({ timestamp: new Date().toISOString(), ...entry });
    this.save("mas_logs_v4", logs);
  },
  getLogs()  { return this.load("mas_logs_v4", []); },

  // Checkpoint system — save pipeline state after each approved agent
  saveCheckpoint(agentName, result) {
    const checkpoints = this.load("mas_checkpoints_v4", {});
    checkpoints[agentName] = { result, timestamp: new Date().toISOString() };
    this.save("mas_checkpoints_v4", checkpoints);
  },
  getCheckpoints()  { return this.load("mas_checkpoints_v4", {}); },
  clearCheckpoints(){ this.remove("mas_checkpoints_v4"); },

  clearAll() {
    const groq   = this.getApiKey();
    const gemini = this.getGeminiKey();
    const openai = this.getOpenAIKey();
    sessionStorage.clear();
    if (groq)   this.saveApiKey(groq);
    if (gemini) this.saveGeminiKey(gemini);
    if (openai) this.saveOpenAIKey(openai);
  }
};
