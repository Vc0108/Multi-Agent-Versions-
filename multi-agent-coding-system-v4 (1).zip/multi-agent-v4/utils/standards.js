// utils/standards.js — v4.0
const CodingStandards = {
  defaults: {
    Python: {
      naming:     "snake_case functions/vars, PascalCase classes, UPPER_SNAKE constants, _ prefix private",
      structure:  "Max 40 lines/function, max 300 lines/file, grouped imports stdlib→third-party→local",
      errors:     "try/except on all I/O, HTTPException with specific codes, never expose raw exceptions",
      security:   "os.getenv() for ALL secrets, bcrypt passwords, JWT via Depends(), Pydantic validation",
      performance:"async/await for all I/O, list comprehensions, module-level caching, avoid N+1 queries"
    },
    JavaScript: {
      naming:     "camelCase functions/vars, PascalCase classes, UPPER_SNAKE constants",
      structure:  "Max 40 lines/function, ES6 modules, grouped imports",
      errors:     "try/catch on all async, proper status codes, never expose stack traces",
      security:   "process.env for secrets, bcrypt passwords, JWT verify on every protected route",
      performance:"async/await, Promise.all for parallel, avoid blocking operations"
    },
    TypeScript: {
      naming:     "camelCase functions/vars, PascalCase classes/interfaces, UPPER_SNAKE constants",
      structure:  "Strict typing on all functions, interfaces for all models, max 40 lines/function",
      errors:     "try/catch with typed errors, proper HTTP status codes, custom error classes",
      security:   "process.env with type validation, bcrypt, JWT, Zod/Yup for input validation",
      performance:"async/await, generics for reusable code, avoid any type"
    },
    Go: {
      naming:     "camelCase unexported, PascalCase exported, short var names in small scopes",
      structure:  "One responsibility per file, error return values, defer for cleanup",
      errors:     "Return errors explicitly, wrap with context, never panic in handlers",
      security:   "os.Getenv for secrets, bcrypt, JWT validation middleware",
      performance:"goroutines for parallel, channels for communication, context for cancellation"
    },
    Java: {
      naming:     "camelCase methods/vars, PascalCase classes, UPPER_SNAKE constants",
      structure:  "Controller→Service→Repository layers, max 40 lines/method, DTOs for requests",
      errors:     "Custom exceptions, @ExceptionHandler, proper HTTP status codes, never expose internals",
      security:   "application.properties for config, BCrypt, Spring Security JWT, @Valid on inputs",
      performance:"@Async for background tasks, pagination for lists, @Cacheable for repeated queries"
    }
  },
  get(lang)  { return this.defaults[lang] || this.defaults.Python; },
  buildPromptBlock(lang, cats=["naming","structure","errors","security","performance"]) {
    const s = this.get(lang);
    return `\n[CODING STANDARDS — ${lang.toUpperCase()}]\n` +
      cats.filter(c=>s[c]).map(c=>`${c.toUpperCase()}: ${s[c]}`).join("\n") + "\n";
  }
};
