// utils/handoff.js — v4.0
const TaskHandoff = {
  chain: [],
  record(from, to, payload) {
    const size = JSON.stringify(payload||{}).length;
    const entry = {
      step: this.chain.length + 1, from, to,
      timestamp: new Date().toISOString(),
      summary: `${from} → ${to}`,
      itemCount: Array.isArray(payload) ? payload.length : (payload?Object.keys(payload).length:0),
      payloadSizeKB: Math.round(size/1024*100)/100,
      approved: false
    };
    this.chain.push(entry);
    Storage.appendLog({ agent:"Handoff", status:"recorded", from, to, sizeKB:entry.payloadSizeKB });
    return entry;
  },
  approve(step) {
    const h = this.chain.find(c=>c.step===step);
    if (h) { h.approved = true; h.approvedAt = new Date().toISOString(); }
  },
  getChain() { return this.chain; },
  clear()    { this.chain = []; }
};
