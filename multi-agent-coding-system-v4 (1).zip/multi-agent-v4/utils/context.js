// utils/context.js — v4.0
// Generates prompts that produce WORKING, properly structured code

const ContextBuilder = {

  // ── SPEC GENERATOR ────────────────────────────────────────────────────────
  specGenerator(task, language, framework, database, complexity, constraints) {
    return {
      system: `You are an expert software architect. Convert a task description into a formal JSON specification.
CRITICAL: Respond with ONLY a valid JSON object. No text before or after.`,
      user: `Create a formal specification for this project.

TASK: ${task}
LANGUAGE: ${language} | FRAMEWORK: ${framework} | DATABASE: ${database}
COMPLEXITY: ${complexity} | CONSTRAINTS: ${constraints||"None"}

Respond with ONLY this JSON:
{
  "project_name": "task_manager",
  "description": "One sentence description",
  "auth_type": "JWT",
  "endpoints": [
    { "method":"POST", "path":"/auth/register", "description":"Register user", "auth_required":false, "business_rules":["username must be unique","password min 8 chars"] },
    { "method":"POST", "path":"/auth/login",    "description":"Login user",    "auth_required":false, "business_rules":["return JWT token on success"] },
    { "method":"GET",  "path":"/tasks",         "description":"Get all tasks", "auth_required":true,  "business_rules":["return only user's own tasks"] },
    { "method":"POST", "path":"/tasks",         "description":"Create task",   "auth_required":true,  "business_rules":["title is required"] },
    { "method":"PUT",  "path":"/tasks/{id}",    "description":"Update task",   "auth_required":true,  "business_rules":["only owner can update"] },
    { "method":"DELETE","path":"/tasks/{id}",   "description":"Delete task",   "auth_required":true,  "business_rules":["only owner can delete"] }
  ],
  "data_models": [
    { "name":"User",  "fields":["id","username","email","hashed_password","created_at"] },
    { "name":"Task",  "fields":["id","title","description","status","priority","due_date","owner_id","created_at"] }
  ],
  "business_rules": ["Users can only access their own data","JWT tokens expire in 30 minutes"],
  "features": ["JWT authentication","CRUD operations","filtering by status and priority"],
  "non_functional": { "auth":"JWT Bearer tokens","hashing":"bcrypt","validation":"Pydantic/Joi" }
}`
    };
  },

  // ── PLANNER ───────────────────────────────────────────────────────────────
  planner(task, language, framework, database, complexity, constraints, spec) {
    const standards = CodingStandards.buildPromptBlock(language, ["naming","structure"]);
    return {
      system: `You are an expert software architect. Break a project into development subtasks.
CRITICAL: Respond with ONLY a JSON object. No text before or after.`,
      user: `Break this project into development subtasks for a WORKING full-stack application.

PROJECT: ${task}
LANGUAGE: ${language} | FRAMEWORK: ${framework} | DATABASE: ${database} | COMPLEXITY: ${complexity}
ENDPOINTS REQUIRED: ${(spec?.endpoints||[]).length} endpoints
AUTH TYPE: ${spec?.auth_type||"JWT"}

${standards}

IMPORTANT: Each subtask must be a SEPARATE MODULE FILE (not main.py):
- database.py / db.js — database connection and session
- models.py / models.js — database models/schemas
- schemas.py / types.ts — request/response validation models
- auth.py / auth.js — authentication logic, JWT, password hashing
- [feature].py / [feature].js — feature-specific routes and logic

Respond with ONLY this JSON:
{
  "project_summary": "What this project does in one sentence",
  "tech_stack": { "language":"${language}", "framework":"${framework}", "database":"${database}" },
  "subtasks": [
    { "id":1, "name":"Database Setup", "description":"Database connection, session management", "type":"setup", "priority":"high", "estimated_complexity":"simple", "dependencies":[], "deliverable":"database.py with engine and session", "filename":"database.py" },
    { "id":2, "name":"Data Models", "description":"SQLAlchemy/Mongoose models for all entities", "type":"model", "priority":"high", "estimated_complexity":"simple", "dependencies":[1], "deliverable":"models.py with all ORM models", "filename":"models.py" },
    { "id":3, "name":"Schemas", "description":"Pydantic/Joi request and response validation models", "type":"schema", "priority":"high", "estimated_complexity":"simple", "dependencies":[2], "deliverable":"schemas.py with all Pydantic models", "filename":"schemas.py" },
    { "id":4, "name":"Authentication", "description":"JWT tokens, password hashing, auth middleware", "type":"auth", "priority":"high", "estimated_complexity":"moderate", "dependencies":[2,3], "deliverable":"auth.py with register/login endpoints and JWT", "filename":"auth.py" },
    { "id":5, "name":"Core Feature Routes", "description":"Main CRUD API endpoints with auth protection", "type":"feature", "priority":"high", "estimated_complexity":"moderate", "dependencies":[2,3,4], "deliverable":"routes file with all endpoints", "filename":"routes.py" }
  ]
}`
    };
  },

  // ── ARCHITECT ─────────────────────────────────────────────────────────────
  architect(spec, plannerData, taskInput) {
    return {
      system: `You are a senior software architect. Design a complete system architecture.
CRITICAL: Respond with ONLY a JSON object. No text before or after.`,
      user: `Design the complete architecture for this project.

PROJECT: ${taskInput.task}
LANGUAGE: ${taskInput.language} | FRAMEWORK: ${taskInput.framework} | DATABASE: ${taskInput.database}
SUBTASKS: ${(plannerData?.subtasks||[]).map(s=>`${s.name} → ${s.filename||s.name}`).join(", ")}
ENDPOINTS: ${(spec?.endpoints||[]).map(e=>`${e.method} ${e.path}`).join(", ")}

Respond with ONLY this JSON:
{
  "components": [
    { "name":"Database Layer", "file":"database.py", "responsibility":"DB connection and session factory" },
    { "name":"Models",         "file":"models.py",   "responsibility":"ORM models for all database tables" },
    { "name":"Schemas",        "file":"schemas.py",  "responsibility":"Pydantic models for validation" },
    { "name":"Auth Router",    "file":"auth.py",     "responsibility":"Register, login, JWT handling" },
    { "name":"Feature Router", "file":"routes.py",   "responsibility":"All feature CRUD endpoints" },
    { "name":"Main Entry",     "file":"main.py",     "responsibility":"App creation, router registration, startup" }
  ],
  "file_structure": [
    "main.py — FastAPI app, routers included, startup events",
    "database.py — engine, SessionLocal, Base, get_db dependency",
    "models.py — SQLAlchemy User, Task (and other) models",
    "schemas.py — Pydantic UserCreate, UserResponse, TaskCreate, TaskResponse",
    "auth.py — /auth/register, /auth/login, JWT create/verify, password hash",
    "routes.py — all feature endpoints with auth dependency injection",
    "requirements.txt — all pip packages",
    ".env.example — DATABASE_URL, SECRET_KEY, ALGORITHM, ACCESS_TOKEN_EXPIRE_MINUTES",
    "frontend/index.html — full responsive UI",
    "frontend/style.css — modern CSS styling",
    "frontend/app.js — API calls, auth handling, dynamic UI"
  ],
  "coding_guidelines": [
    "Each file is a standalone module — never duplicate class definitions",
    "main.py only imports and includes routers — no business logic",
    "database.py exports: engine, SessionLocal, Base, get_db",
    "models.py imports Base from database.py",
    "auth.py uses APIRouter with prefix /auth",
    "routes.py uses APIRouter — never defines app = FastAPI()",
    "All env vars via os.getenv('VAR','default') — always include safe default",
    "Use Depends(get_db) for database sessions",
    "Use Depends(get_current_user) for protected routes"
  ],
  "security_considerations": [
    "JWT secret from environment variable with safe default",
    "Passwords hashed with bcrypt before storage",
    "All protected endpoints use Depends(get_current_user)",
    "Input validation via Pydantic models on all endpoints",
    "CORS enabled for frontend to communicate with backend"
  ],
  "data_flow": "Request → FastAPI router → Pydantic validation → Service logic → SQLAlchemy ORM → PostgreSQL → Response"
}`
    };
  },

  // ── CODER ─────────────────────────────────────────────────────────────────
  coder(subtask, language, framework, database, previousCode, spec, architecture, memoryContext) {
    const relevantEndpoints = spec ? (spec.endpoints||[])
      .filter(ep => {
        const sl = subtask.name.toLowerCase();
        const path = ep.path.toLowerCase();
        return path.includes(sl.split(" ")[0]) || sl.includes((path.split("/")[1])||"") ||
               subtask.name.toLowerCase().includes("auth") ||
               subtask.name.toLowerCase().includes("route") ||
               subtask.name.toLowerCase().includes("feature");
      })
      .map(ep => `${ep.method} ${ep.path}: ${ep.description}\n  Rules: ${(ep.business_rules||[]).join(", ")}`)
      .join("\n") : "";

    const archGuidelines = (architecture?.coding_guidelines||[]).join("\n");
    const dataModels     = (spec?.data_models||[]).map(m=>`${m.name}: ${m.fields.join(", ")}`).join("\n");
    const standards      = CodingStandards.buildPromptBlock(language, ["naming","structure","errors","security","performance"]);
    const retryNote      = subtask._retryNote ? `\n⚠️ ${subtask._retryNote}\n` : "";

    return {
      system: `You are a senior ${language} developer. Write COMPLETE, WORKING, PRODUCTION-READY code.

ABSOLUTE RULES — NEVER BREAK:
1. Write COMPLETE code — every function must have a REAL implementation
2. NEVER write placeholder text: no "TODO", "pass", "implement this", "coming soon"
3. NEVER name the file main.py — use the filename specified in the subtask
4. NEVER define app = FastAPI() — that only goes in main.py (auto-generated separately)
5. NEVER define duplicate classes — each model/schema defined exactly once
6. ALWAYS use os.getenv('VAR', 'safe_default') — never os.getenv('VAR') alone
7. ALWAYS define an APIRouter() for endpoints — never use app directly
8. Include ALL required imports at the top of the file
9. Respond with ONLY a JSON object — no text before or after
${memoryContext||""}`,

      user: `Write complete ${language} code for this module.

SUBTASK: ${subtask.name}
FILENAME: ${subtask.filename || subtask.name.toLowerCase().replace(/\s+/g,"_")+".py"}
DESCRIPTION: ${subtask.description}
FRAMEWORK: ${framework} | DATABASE: ${database}
DELIVERABLE: ${subtask.deliverable}
${retryNote}
DATA MODELS NEEDED:
${dataModels}

${relevantEndpoints ? `ENDPOINTS TO IMPLEMENT:\n${relevantEndpoints}` : ""}

ARCHITECTURE GUIDELINES:
${archGuidelines}

${standards}

PREVIOUSLY WRITTEN CODE (do NOT repeat, only import from these):
${previousCode ? previousCode.substring(0,600) : "None yet — this is the first file"}

WORKING CODE REQUIREMENTS:
- database.py must export: engine, SessionLocal, Base, get_db
- models.py must import Base from database and define all ORM models
- schemas.py must define all Pydantic request/response models
- auth.py must implement complete JWT logic with register + login endpoints
- routes.py must implement all CRUD endpoints with auth protection
- All files must work together without import errors

Respond with ONLY this JSON:
{
  "subtask_id": ${subtask.id},
  "subtask_name": "${subtask.name}",
  "filename": "${subtask.filename || subtask.name.toLowerCase().replace(/\s+/g,"_")+".py"}",
  "code": "# Complete working code here\\nimport os\\n...",
  "explanation": "What this file does and exports",
  "dependencies_used": ["fastapi","sqlalchemy","passlib"],
  "exports": ["function_name", "ClassName"]
}`
    };
  },

  // ── REVIEWER ──────────────────────────────────────────────────────────────
  reviewer(subtaskName, code, language, spec) {
    const standards = CodingStandards.buildPromptBlock(language, ["naming","structure","errors","security"]);
    const specRules = spec ? (spec.business_rules||[]).slice(0,5).join(", ") : "";
    return {
      system: `You are a senior code reviewer. Review code thoroughly.
CRITICAL: Respond with ONLY a JSON object. Keep text fields under 30 words.`,
      user: `Review this ${language} code for: ${subtaskName}
${specRules ? `SPEC RULES: ${specRules}` : ""}
${standards}

CODE:
${code.substring(0,1500)}

Check for: placeholder code, missing implementations, security issues, import errors, duplicate definitions.

Respond with ONLY this JSON:
{
  "verdict": "PASS",
  "score": 85,
  "issues": [{"severity":"medium","type":"security","description":"Short description","suggestion":"How to fix"}],
  "strengths": ["Good error handling"],
  "revised_code": "improved code or empty string if already good"
}`
    };
  },

  // ── TESTER ────────────────────────────────────────────────────────────────
  tester(subtaskName, code, language, framework) {
    return {
      system: `You are a QA engineer. Respond with ONLY a JSON object.`,
      user: `Analyze this ${language} code and generate test cases.

FILE: ${subtaskName}
CODE SNIPPET: ${code.substring(0,400)}

Respond with ONLY this JSON:
{
  "verdict": "PASS",
  "test_code": "import pytest\\n\\ndef test_example():\\n    assert True",
  "test_cases": [
    {"name":"test_success","type":"happy_path","description":"Tests main flow","expected":"200 OK","status":"PASS","failure_reason":null},
    {"name":"test_invalid","type":"edge_case","description":"Tests bad input","expected":"400 error","status":"PASS","failure_reason":null},
    {"name":"test_unauth", "type":"error_case","description":"Tests no auth","expected":"401 error","status":"PASS","failure_reason":null}
  ],
  "needs_debug": false
}`
    };
  },

  // ── DEBUGGER ──────────────────────────────────────────────────────────────
  debuggerPrompt(subtaskName, code, errorDetails, failedTests, previousFixes, language) {
    const standards = CodingStandards.buildPromptBlock(language, ["errors","security"]);
    return {
      system: `You are an expert debugger. Fix ALL issues completely.
RULES: Write COMPLETE fixed code. NEVER use placeholders. Respond with ONLY JSON.
${standards}`,
      user: `Fix this failing code for: ${subtaskName}

ERROR: ${String(errorDetails).substring(0,300)}
FAILED TESTS: ${JSON.stringify((failedTests||[]).slice(0,3))}
PREVIOUS FIX ATTEMPTS: ${(previousFixes||[]).slice(-1).join(" | ")||"None"}

FAILING CODE:
${code.substring(0,800)}

Respond with ONLY this JSON:
{
  "root_cause": "Specific explanation of what caused the failure",
  "fix_applied": "Exactly what was changed to fix it",
  "fixed_code": "# Complete fixed code here",
  "confidence": "high",
  "explanation": "Why this fix resolves the issue"
}`
    };
  },

  // ── FRONTEND AGENT ────────────────────────────────────────────────────────
  frontendAgent(spec, taskInput, allRoutes) {
    const endpoints = (spec?.endpoints||[]).map(e=>`${e.method} ${e.path}: ${e.description} (auth:${e.auth_required})`).join("\n");
    return {
      system: `You are a senior frontend developer. Build a COMPLETE, WORKING, BEAUTIFUL frontend.
RULES: Generate real, complete HTML/CSS/JS. No placeholders. Respond with ONLY JSON.`,
      user: `Build a complete frontend for this API.

PROJECT: ${taskInput.task}
API BASE URL: http://localhost:8000
AUTH: JWT Bearer token

ENDPOINTS:
${endpoints}

DATA MODELS:
${(spec?.data_models||[]).map(m=>`${m.name}: ${m.fields.join(", ")}`).join("\n")}

REQUIREMENTS:
1. index.html — Full responsive single-page app with:
   - Login and Register forms (calls /auth/login and /auth/register)
   - Dashboard that shows data after login
   - Create/Edit forms for all main entities
   - Delete buttons with confirmation
   - Filter/search if applicable
   - Error messages for failed API calls
   - Success messages for completed actions
   - Logout button that clears token

2. style.css — Modern, clean styling with:
   - Professional color scheme
   - Responsive design (works on mobile)
   - Card-based layout for data display
   - Form styling with validation states
   - Loading states for API calls

3. app.js — Complete JavaScript with:
   - JWT token storage in localStorage
   - Auto-attach token to all protected requests via fetch headers
   - All API calls implemented (register, login, CRUD operations)
   - Dynamic DOM updates without page reload
   - Error handling for 400, 401, 403, 404, 500 responses
   - Auto-redirect to login if token expires

Respond with ONLY this JSON (use \\n for newlines):
{
  "html": "<!DOCTYPE html>\\n<html>\\n...",
  "css":  "* { box-sizing: border-box; }\\n...",
  "js":   "const API = 'http://localhost:8000';\\n...",
  "description": "What this frontend does"
}`
    };
  },

  // ── DATABASE AGENT ────────────────────────────────────────────────────────
  databaseAgent(spec, taskInput) {
    const models = (spec?.data_models||[]).map(m=>`${m.name}: ${m.fields.join(", ")}`).join("\n");
    return {
      system: `You are a database architect. Generate complete, working database files.
CRITICAL: Respond with ONLY a JSON object.`,
      user: `Generate complete database setup for this project.

PROJECT: ${taskInput.task}
DATABASE: ${taskInput.database}
LANGUAGE: ${taskInput.language}

DATA MODELS:
${models}

Generate:
1. Complete SQL schema with proper types, constraints, indexes
2. Alembic migration file (for Python) or equivalent
3. Seed data with realistic sample records
4. Database connection configuration

Respond with ONLY this JSON:
{
  "schema": "-- SQL schema\\nCREATE TABLE users (\\n  id SERIAL PRIMARY KEY,\\n  ...",
  "migration": "# Alembic migration\\nfrom alembic import op\\nimport sqlalchemy as sa\\n...",
  "seed_data": "# Seed script\\nfrom database import SessionLocal\\nfrom models import User\\n...",
  "indexes": ["CREATE INDEX idx_tasks_owner ON tasks(owner_id);"],
  "description": "Database setup description"
}`
    };
  },

  // ── DEVOPS AGENT ──────────────────────────────────────────────────────────
  devopsAgent(taskInput, spec) {
    return {
      system: `You are a DevOps engineer. Generate complete, working Docker and CI/CD files.
CRITICAL: Respond with ONLY a JSON object.`,
      user: `Generate complete DevOps setup for this project.

PROJECT: ${taskInput.task}
LANGUAGE: ${taskInput.language} | FRAMEWORK: ${taskInput.framework} | DATABASE: ${taskInput.database}

Generate:
1. Dockerfile — multi-stage, production-ready
2. docker-compose.yml — app + database + optional redis
3. .github/workflows/ci.yml — test and lint on push
4. .env.example — all required environment variables
5. setup.sh — one-command local setup script

Respond with ONLY this JSON:
{
  "dockerfile": "FROM python:3.11-slim\\nWORKDIR /app\\n...",
  "docker_compose": "version: '3.8'\\nservices:\\n  app:\\n    build: .\\n    ...",
  "ci_cd": "name: CI\\non: [push]\\njobs:\\n  test:\\n    ...",
  "env_example": "DATABASE_URL=postgresql://user:password@localhost:5432/dbname\\nSECRET_KEY=your-secret-key\\n...",
  "setup_script": "#!/bin/bash\\npip install -r requirements.txt\\ncp .env.example .env\\n...",
  "description": "DevOps setup description"
}`
    };
  },

  // ── DOCUMENTER ────────────────────────────────────────────────────────────
  documenter(projectSummary, techStack, allCode, spec) {
    const endpointDocs = (spec?.endpoints||[]).slice(0,8).map(e=>`${e.method} ${e.path}: ${e.description}`).join("\n");
    const standards    = CodingStandards.buildPromptBlock(techStack.language||"Python",["naming","structure"]);
    return {
      system: `You are a technical documentation writer. Write complete, accurate documentation.
RULES: Reference actual endpoints and function names. Respond with ONLY JSON. Use \\n for line breaks.`,
      user: `Write complete documentation for this project.

PROJECT: ${projectSummary}
STACK: ${techStack.language}, ${techStack.framework}, ${techStack.database}
${endpointDocs ? `\nKEY ENDPOINTS:\n${endpointDocs}` : ""}
${standards}

CODE SAMPLE:
${allCode.substring(0,600)}

Respond with ONLY this JSON:
{
  "readme": "# Project Title\\n\\n## Overview\\n...\\n\\n## Features\\n...\\n\\n## Quick Start\\n...",
  "api_reference": "## API Reference\\n\\n### Authentication\\n\\n#### POST /auth/register\\n...",
  "setup_guide": "## Setup Guide\\n\\n### Prerequisites\\n- Python 3.11+\\n\\n### Installation\\n1. Clone repo\\n2. pip install -r requirements.txt\\n3. cp .env.example .env\\n4. uvicorn main:app --reload",
  "architecture_overview": "## Architecture\\n\\n### Layers\\n...",
  "functions_documented": [{"name":"get_current_user","description":"JWT auth dependency","params":"token: str","returns":"User"}]
}`
    };
  },

  // ── SPEC COMPLIANCE ───────────────────────────────────────────────────────
  specValidator(spec, allGeneratedCode) {
    if (!spec||!spec.endpoints) return null;
    const results = { total_endpoints:spec.endpoints.length, implemented:[], missing:[], partial:[] };
    spec.endpoints.forEach(ep => {
      const pattern    = new RegExp(`@(app|router)\\.(${ep.method.toLowerCase()})\\(["']${ep.path.replace(/\{/g,"\\{").replace(/\}/g,"\\}")}["']`,"i");
      const altPattern = new RegExp(ep.path.replace(/\{(\w+)\}/g,"[^/]+").replace(/\//g,"\\/"),"i");
      if      (pattern.test(allGeneratedCode))    results.implemented.push({method:ep.method,path:ep.path,status:"found"});
      else if (altPattern.test(allGeneratedCode)) results.partial.push({method:ep.method,path:ep.path,status:"partial"});
      else                                        results.missing.push({method:ep.method,path:ep.path,status:"missing"});
    });
    const score = spec.endpoints.length > 0
      ? Math.round(((results.implemented.length + results.partial.length*0.5)/spec.endpoints.length)*100) : 100;
    results.compliance_score = score;
    results.grade = score>=90?"A":score>=75?"B":score>=60?"C":score>=40?"D":"F";
    return results;
  }
};
