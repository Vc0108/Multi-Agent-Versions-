// utils/context.js
const ContextBuilder = {

  // ── PLANNER ───────────────────────────────────────────────────────────────
  planner(task, language, framework, database, complexity, constraints, spec) {
    const specContext = spec ? `
FORMAL SPEC:
- Endpoints required: ${(spec.endpoints||[]).length}
- Auth: ${spec.auth_type || "JWT"}, Storage: ${spec.storage_type || "in-memory"}
- Features: ${(spec.features||[]).join(", ")}` : "";

    const standards = CodingStandards.buildPromptBlock(language, ["naming","structure"]);

    return {
      system: `You are an expert software architect. Break down a development task into clear subtasks.
CRITICAL: Respond with ONLY a JSON object. Start with { and end with }. No text before or after.`,
      user: `Break down this project into development subtasks.

PROJECT: ${task}
LANGUAGE: ${language} | FRAMEWORK: ${framework} | DATABASE: ${database}
COMPLEXITY: ${complexity} | CONSTRAINTS: ${constraints || "None"}
${specContext}

${standards}

Respond with ONLY this JSON:
{
  "project_summary": "One sentence describing what this project does",
  "tech_stack": { "language": "${language}", "framework": "${framework}", "database": "${database}" },
  "subtasks": [
    {
      "id": 1,
      "name": "Project Setup",
      "description": "Initialize project structure, create main.py, install dependencies",
      "type": "setup",
      "priority": "high",
      "estimated_complexity": "simple",
      "dependencies": [],
      "deliverable": "requirements.txt and main.py skeleton"
    },
    {
      "id": 2,
      "name": "Core Business Logic",
      "description": "Implement the main features and helper functions",
      "type": "feature",
      "priority": "high",
      "estimated_complexity": "moderate",
      "dependencies": [1],
      "deliverable": "Working core logic"
    },
    {
      "id": 3,
      "name": "API Routes",
      "description": "Create all REST API endpoints with request/response models",
      "type": "feature",
      "priority": "high",
      "estimated_complexity": "moderate",
      "dependencies": [2],
      "deliverable": "All API endpoints working"
    }
  ]}`
    };
  },

  // ── CODER ─────────────────────────────────────────────────────────────────
  coder(subtask, language, framework, database, previousCode, spec, architecture, memoryContext) {
    const prevSnippet = previousCode ? previousCode.substring(0, 500) : "None";
    const retryNote   = subtask._retryNote ? `\n⚠️ ${subtask._retryNote}\n` : "";

    const relevantEndpoints = spec ? (spec.endpoints || [])
      .filter(ep => {
        const sl = subtask.name.toLowerCase();
        const path = ep.path.toLowerCase();
        return path.includes(sl.split(" ")[0]) || sl.includes((path.split("/")[1]) || "");
      })
      .map(ep => `${ep.method} ${ep.path}: ${ep.description}\n  Rules: ${(ep.business_rules||[]).join(", ")}`)
      .join("\n") : "";

    const archGuidelines = architecture ? (architecture.coding_guidelines || []).join("\n") : "";
    const standards = CodingStandards.buildPromptBlock(language, ["naming","structure","errors","security","performance"]);

    return {
      system: `You are a senior ${language} developer with 10 years of experience.

STRICT RULES — NEVER BREAK THESE:
1. Write COMPLETE, WORKING, PRODUCTION-READY code
2. NEVER write placeholder text like "not provided", "implement this", "TODO", "coming soon"
3. NEVER leave functions empty — every function must have a real implementation
4. NEVER truncate — write the full implementation always
5. Respond with ONLY a JSON object — no text before or after
${memoryContext ? `\n${memoryContext}` : ""}`,

      user: `Write complete ${language} code for this feature.

SUBTASK: ${subtask.name}
DESCRIPTION: ${subtask.description}
FRAMEWORK: ${framework} | DATABASE: ${database}
DELIVERABLE: ${subtask.deliverable}
${retryNote}
${relevantEndpoints ? `\nENDPOINTS TO IMPLEMENT:\n${relevantEndpoints}` : ""}
${archGuidelines ? `\nARCHITECTURE GUIDELINES:\n${archGuidelines}` : ""}

${standards}

CONTEXT — already written code:
${prevSnippet}

Respond with ONLY this JSON (use \\n for newlines in the code string):
{
  "subtask_id": ${subtask.id},
  "subtask_name": "${subtask.name}",
  "filename": "descriptive_filename.py",
  "code": "# Complete working code here\\nimport os\\n...",
  "explanation": "What this file does and what functions it contains",
  "dependencies_used": ["fastapi", "sqlalchemy"]
}`
    };
  },

  // ── REVIEWER ──────────────────────────────────────────────────────────────
  reviewer(subtaskName, code, language, spec) {
    const codeSnippet = code.substring(0, 1000);
    const specRules   = spec ? (spec.business_rules || []).slice(0,3).join(", ") : "";
    const standards   = CodingStandards.buildPromptBlock(language, ["naming","structure","errors","security"]);

    return {
      system: `You are a senior code reviewer. Review code thoroughly against coding standards.
CRITICAL: Respond with ONLY a JSON object. Start with { and end with }. Keep all text fields under 20 words.`,
      user: `Review this ${language} code for: ${subtaskName}
${specRules ? `\nSPEC RULES: ${specRules}` : ""}

${standards}

CODE:
${codeSnippet}

Check violations of the coding standards above AND general bugs, security issues, incomplete implementations.

Respond with ONLY this JSON:
{
  "verdict": "PASS",
  "score": 85,
  "standards_violations": [
    {
      "category": "naming",
      "rule": "Use snake_case for functions",
      "violation": "Function getUserData uses camelCase",
      "line_hint": "def getUserData()"
    }
  ],
  "issues": [
    {
      "severity": "medium",
      "type": "security",
      "description": "Missing input validation",
      "suggestion": "Add Pydantic validators to request models"
    }
  ],
  "strengths": ["Good error handling", "Clean structure"],
  "revised_code": "full improved code here or empty string if already good"
}`
    };
  },

  // ── TESTER ────────────────────────────────────────────────────────────────
  tester(subtaskName, code, language, framework) {
    return {
      system: `You are a QA engineer. Respond with ONLY a JSON object. Start with { end with }. No markdown.`,
      user: `Analyze this ${language} code and list what should be tested.

FILE: ${subtaskName}
CODE SNIPPET: ${code.substring(0, 300)}

Respond with ONLY this JSON — keep ALL strings very short:
{
  "verdict": "PASS",
  "test_cases": [
    {"name": "test_success", "type": "happy_path", "description": "Tests main flow", "expected": "200 OK", "status": "PASS", "failure_reason": null},
    {"name": "test_invalid", "type": "edge_case", "description": "Tests bad input", "expected": "400 error", "status": "PASS", "failure_reason": null},
    {"name": "test_missing", "type": "error_case", "description": "Tests not found", "expected": "404 error", "status": "PASS", "failure_reason": null}
  ]}`
    };
  },

  // ── DEBUGGER ──────────────────────────────────────────────────────────────
  debuggerPrompt(subtaskName, code, errorDetails, failedTests, previousFixes, language) {
    const standards = language
      ? CodingStandards.buildPromptBlock(language, ["errors","security"])
      : "";

    return {
      system: `You are an expert debugger. Fix ALL issues in the code completely.

STRICT RULES:
1. Write the COMPLETE fixed code — not just the changed parts
2. NEVER write placeholder text
3. Every fix must be a real implementation
4. Respond with ONLY a JSON object
${standards ? `\n${standards}` : ""}`,

      user: `Fix this failing code for: ${subtaskName}

ERROR: ${String(errorDetails).substring(0, 300)}
FAILED TESTS: ${JSON.stringify((failedTests || []).slice(0, 3))}
PREVIOUS FIX ATTEMPTS: ${(previousFixes || []).slice(-1).join(" | ") || "None — first attempt"}

FAILING CODE:
${code.substring(0, 600)}

Respond with ONLY this JSON:
{
  "root_cause": "Specific explanation of what caused the failure",
  "fix_applied": "Exactly what was changed to fix it",
  "fixed_code": "# Complete fixed code\\nimport os\\n...",
  "confidence": "high",
  "explanation": "Why this specific fix resolves the issue"
}`
    };
  },

  // ── DOCUMENTER ────────────────────────────────────────────────────────────
  documenter(projectSummary, techStack, allCode, spec) {
    const codeSnippet  = allCode.substring(0, 800);
    const endpointDocs = spec ? (spec.endpoints || []).slice(0,5)
      .map(e => `${e.method} ${e.path}: ${e.description}`).join("\n") : "";
    const standards    = CodingStandards.buildPromptBlock(techStack.language || "Python", ["naming","structure"]);

    return {
      system: `You are a technical documentation writer. Write clear, complete documentation.

STRICT RULES:
1. Write REAL documentation based on the actual code
2. NEVER write "not provided" or "add documentation here"
3. Include actual endpoint names and function names from the code
4. Mention the coding standards that were applied
5. Respond with ONLY a JSON object. Use \\n for line breaks inside strings.`,

      user: `Write complete documentation for this project.

PROJECT: ${projectSummary}
STACK: ${techStack.language}, ${techStack.framework}, ${techStack.database}
${endpointDocs ? `\nKEY ENDPOINTS:\n${endpointDocs}` : ""}
${standards}

CODE:
${codeSnippet}

Respond with ONLY this JSON (use \\n for all line breaks):
{
  "readme": "# Project\\n\\n## Overview\\n...\\n\\n## Standards Applied\\n...",
  "api_reference": "## API Reference\\n\\n### Endpoints\\n...",
  "setup_guide": "## Setup\\n\\n1. pip install -r requirements.txt\\n2. uvicorn main:app --reload",
  "architecture_overview": "## Architecture\\n\\n...",
  "functions_documented": [{"name": "function_name", "description": "What it does", "params": "param: type", "returns": "type"}]
}`
    };
  },

  // ── SPEC COMPLIANCE VALIDATOR (local) ────────────────────────────────────
  specValidator(spec, allGeneratedCode) {
    if (!spec || !spec.endpoints) return null;
    const results = {
      total_endpoints: spec.endpoints.length,
      implemented: [], missing: [], partial: [],
      compliance_score: 0,
      business_rules_checked: [],
    };

    spec.endpoints.forEach(ep => {
      const pattern = new RegExp(
        `@(app|router)\\.(${ep.method.toLowerCase()})\\(["']${ep.path.replace(/\{/g,"\\{").replace(/\}/g,"\\}")}["']`, "i"
      );
      const altPattern = new RegExp(
        ep.path.replace(/\{(\w+)\}/g, "[^/]+").replace(/\//g, "\\/"), "i"
      );
      if (pattern.test(allGeneratedCode)) {
        results.implemented.push({ method: ep.method, path: ep.path, status: "found" });
      } else if (altPattern.test(allGeneratedCode)) {
        results.partial.push({ method: ep.method, path: ep.path, status: "partial_match" });
      } else {
        results.missing.push({ method: ep.method, path: ep.path, status: "missing" });
      }
    });

    (spec.business_rules || []).forEach(rule => {
      const keywords = rule.toLowerCase().split(" ").filter(w => w.length > 4);
      const found = keywords.some(kw => allGeneratedCode.toLowerCase().includes(kw));
      results.business_rules_checked.push({ rule, implemented: found });
    });

    const implementedCount = results.implemented.length + (results.partial.length * 0.5);
    results.compliance_score = spec.endpoints.length > 0
      ? Math.round((implementedCount / spec.endpoints.length) * 100) : 100;
    results.missingEndpoints = results.missing.map(e => `${e.method} ${e.path}`);
    results.grade = results.compliance_score >= 90 ? "A"
                  : results.compliance_score >= 75 ? "B"
                  : results.compliance_score >= 60 ? "C"
                  : results.compliance_score >= 40 ? "D" : "F";
    return results;
  }

};