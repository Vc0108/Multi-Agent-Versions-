// utils/storage.js
// Session storage — manages state across agents in a single run

const Storage = {

  // ── SAVE / LOAD SESSION ────────────────────────────────────────────────────
  saveSession(data) {
    sessionStorage.setItem("mas_session", JSON.stringify(data));
  },

  loadSession() {
    const raw = sessionStorage.getItem("mas_session");
    return raw ? JSON.parse(raw) : null;
  },

  clearSession() {
    sessionStorage.removeItem("mas_session");
  },

  // ── API KEY ────────────────────────────────────────────────────────────────
  saveApiKey(key) {
    sessionStorage.setItem("groq_api_key", key);
  },

  getApiKey() {
    return sessionStorage.getItem("groq_api_key");
  },

  clearApiKey() {
    sessionStorage.removeItem("groq_api_key");
  },

  // ── AGENT OUTPUTS ──────────────────────────────────────────────────────────
  savePlannerOutput(data) {
    sessionStorage.setItem("mas_planner", JSON.stringify(data));
  },

  getPlannerOutput() {
    const raw = sessionStorage.getItem("mas_planner");
    return raw ? JSON.parse(raw) : null;
  },

  saveCoderOutputs(data) {
    sessionStorage.setItem("mas_coder", JSON.stringify(data));
  },

  getCoderOutputs() {
    const raw = sessionStorage.getItem("mas_coder");
    return raw ? JSON.parse(raw) : [];
  },

  saveReviewerOutputs(data) {
    sessionStorage.setItem("mas_reviewer", JSON.stringify(data));
  },

  getReviewerOutputs() {
    const raw = sessionStorage.getItem("mas_reviewer");
    return raw ? JSON.parse(raw) : [];
  },

  saveTesterOutputs(data) {
    sessionStorage.setItem("mas_tester", JSON.stringify(data));
  },

  getTesterOutputs() {
    const raw = sessionStorage.getItem("mas_tester");
    return raw ? JSON.parse(raw) : [];
  },

  saveDebuggerOutputs(data) {
    sessionStorage.setItem("mas_debugger", JSON.stringify(data));
  },

  getDebuggerOutputs() {
    const raw = sessionStorage.getItem("mas_debugger");
    return raw ? JSON.parse(raw) : [];
  },

  saveDocumenterOutput(data) {
    sessionStorage.setItem("mas_documenter", JSON.stringify(data));
  },

  getDocumenterOutput() {
    const raw = sessionStorage.getItem("mas_documenter");
    return raw ? JSON.parse(raw) : null;
  },

  // ── AUDIT LOG ──────────────────────────────────────────────────────────────
  appendLog(entry) {
    const logs = this.getLogs();
    logs.push({ timestamp: new Date().toISOString(), ...entry });
    sessionStorage.setItem("mas_logs", JSON.stringify(logs));
  },

  getLogs() {
    const raw = sessionStorage.getItem("mas_logs");
    return raw ? JSON.parse(raw) : [];
  },

  clearLogs() {
    sessionStorage.removeItem("mas_logs");
  },

  // ── CLEAR ALL ──────────────────────────────────────────────────────────────
  clearAll() {
    const key = this.getApiKey();
    sessionStorage.clear();
    if (key) this.saveApiKey(key); // keep API key
  }

};
