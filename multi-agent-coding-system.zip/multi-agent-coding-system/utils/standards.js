// utils/standards.js
// Coding Standards Manager — defaults per language, user-overridable

const CodingStandards = {

  STORAGE_KEY: "codingStandards_v1",

  // ── DEFAULTS per language ─────────────────────────────────────────────────
  DEFAULTS: {
    Python: {
      naming: [
        "Use snake_case for variables, functions, and file names",
        "Use PascalCase for class names",
        "Use UPPER_SNAKE_CASE for constants",
        "Prefix private methods/attributes with underscore (_method)",
        "Use descriptive names — avoid single letters except loop counters"
      ],
      structure: [
        "Max function length: 40 lines — split larger functions",
        "Max file length: 300 lines — use modules for larger files",
        "Group imports: stdlib → third-party → local, separated by blank lines",
        "One class per file for major domain models",
        "Use APIRouter() for each feature module, not one giant router"
      ],
      errors: [
        "Always use try/except on external calls and DB operations",
        "Raise HTTPException with specific status codes (400, 401, 403, 404, 422)",
        "Never expose raw exception messages in API responses",
        "Log errors server-side with context before returning generic response",
        "Validate all inputs with Pydantic before processing"
      ],
      security: [
        "Never hardcode secrets — use os.getenv() for all credentials",
        "Hash all passwords with passlib bcrypt before storing",
        "Validate JWT on every protected endpoint using Depends()",
        "Sanitize and validate all user inputs via Pydantic BaseModel",
        "Return 401 for auth errors, never leak token details in responses"
      ],
      performance: [
        "Use async/await for all I/O-bound operations",
        "Use list comprehensions instead of loops where readable",
        "Cache frequently accessed in-memory data with module-level dicts",
        "Avoid N+1 queries — fetch related data in single operations",
        "Use Pydantic response_model to limit fields returned to client"
      ]
    },

    JavaScript: {
      naming: [
        "Use camelCase for variables and functions",
        "Use PascalCase for classes and React components",
        "Use UPPER_SNAKE_CASE for constants",
        "Use descriptive verb-noun names for functions (getUserById, createOrder)",
        "Prefix boolean variables with is/has/can (isActive, hasPermission)"
      ],
      structure: [
        "Max function length: 30 lines — extract helper functions",
        "Use ES6+ features: const/let, arrow functions, destructuring, spread",
        "Group related functions in modules with named exports",
        "Separate business logic from route handlers",
        "Use middleware for cross-cutting concerns (auth, logging, validation)"
      ],
      errors: [
        "Always use try/catch on async operations",
        "Use next(error) in Express to pass errors to error middleware",
        "Return consistent error JSON: { error: string, message: string }",
        "Validate request body with express-validator or Joi",
        "Handle Promise rejections — never leave unhandled rejections"
      ],
      security: [
        "Never hardcode secrets — use process.env for all credentials",
        "Hash passwords with bcrypt (saltRounds >= 12)",
        "Verify JWT on every protected route using middleware",
        "Use helmet.js for security headers",
        "Sanitize inputs to prevent XSS and injection attacks"
      ],
      performance: [
        "Use async/await consistently — avoid callback hell",
        "Use Promise.all() for parallel async operations",
        "Cache results in-memory using Map or simple objects",
        "Use compression middleware for API responses",
        "Avoid blocking the event loop — never use sync file I/O"
      ]
    },

    TypeScript: {
      naming: [
        "Use camelCase for variables and functions",
        "Use PascalCase for classes, interfaces, types, and enums",
        "Prefix interfaces with I (IUser) or use plain names (User)",
        "Use descriptive generic type names (T, TItem not just T)",
        "Use UPPER_SNAKE_CASE for enum values"
      ],
      structure: [
        "Define explicit return types on all public functions",
        "Use interface for object shapes, type for unions/intersections",
        "Avoid 'any' — use 'unknown' and type guards instead",
        "Use strict mode in tsconfig.json",
        "Separate types into dedicated .types.ts or .interfaces.ts files"
      ],
      errors: [
        "Use typed error classes extending Error",
        "Always handle rejected promises with try/catch or .catch()",
        "Define error response types — never return untyped errors",
        "Use Result<T, E> pattern for operations that can fail",
        "Validate external data at boundaries with type guards"
      ],
      security: [
        "Never hardcode secrets — use process.env with type checking",
        "Type all JWT payloads explicitly",
        "Use readonly on sensitive data structures",
        "Validate all external inputs at API boundaries",
        "Use strict null checks to prevent null-reference errors"
      ],
      performance: [
        "Use readonly arrays and objects for immutable data",
        "Avoid type assertions (as Type) — use type guards instead",
        "Use generics to avoid code duplication",
        "Use lazy evaluation for expensive computations",
        "Prefer interfaces over type aliases for better IDE performance"
      ]
    },

    Go: {
      naming: [
        "Use camelCase for unexported identifiers, PascalCase for exported",
        "Use short names in small scopes (i, err, ctx)",
        "Interface names should describe behaviour with -er suffix (Reader, Writer)",
        "Package names should be short lowercase single words",
        "Avoid stuttering (user.UserID → user.ID)"
      ],
      structure: [
        "Handle errors immediately after they occur — don't defer error handling",
        "Keep functions small and focused on a single responsibility",
        "Use table-driven tests for comprehensive test coverage",
        "Group related functionality in packages",
        "Use context.Context as first parameter in long-running functions"
      ],
      errors: [
        "Always check and handle returned errors — never use _",
        "Wrap errors with fmt.Errorf('context: %w', err) for stack traces",
        "Return (value, error) from functions that can fail",
        "Use errors.Is() and errors.As() for error type checking",
        "Define sentinel errors as package-level variables"
      ],
      security: [
        "Never log sensitive data (passwords, tokens)",
        "Use crypto/rand for all random token generation",
        "Validate and sanitize all inputs before processing",
        "Use prepared statements for all DB queries",
        "Store secrets in environment variables only"
      ],
      performance: [
        "Use goroutines for concurrent I/O operations",
        "Preallocate slices when size is known: make([]T, 0, cap)",
        "Use sync.Pool for frequently allocated objects",
        "Profile before optimising — avoid premature optimisation",
        "Use buffered channels to avoid goroutine blocking"
      ]
    },

    Java: {
      naming: [
        "Use camelCase for variables and methods",
        "Use PascalCase for classes and interfaces",
        "Use UPPER_SNAKE_CASE for constants",
        "Prefix interfaces with I only if needed to avoid conflicts",
        "Use nouns for classes, verbs for methods (getUser, createOrder)"
      ],
      structure: [
        "Follow SOLID principles — single responsibility per class",
        "Use constructor injection for dependencies",
        "Keep controllers thin — delegate logic to service layer",
        "Use DTOs to transfer data between layers",
        "Place related classes in the same package"
      ],
      errors: [
        "Use specific exception types — avoid catching Exception broadly",
        "Use @ControllerAdvice for global exception handling in Spring",
        "Always include meaningful messages in exceptions",
        "Log exceptions with full stack trace at ERROR level",
        "Use Optional<T> to avoid NullPointerException"
      ],
      security: [
        "Store secrets in application.properties or environment variables",
        "Use BCryptPasswordEncoder for password hashing",
        "Validate JWT in security filter chain",
        "Use @Valid and Bean Validation for input validation",
        "Never expose stack traces in API responses"
      ],
      performance: [
        "Use @Transactional only on methods that need it",
        "Use pagination for list endpoints — never return unbounded lists",
        "Use lazy loading for large associations",
        "Cache expensive operations with @Cacheable",
        "Use StringBuilder for string concatenation in loops"
      ]
    }
  },

  // ── GET standards (user overrides or defaults) ────────────────────────────
  get(language) {
    try {
      const saved = sessionStorage.getItem(this.STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed[language]) return parsed[language];
      }
    } catch(e) {}
    return this.DEFAULTS[language] || this.DEFAULTS["Python"];
  },

  // ── SAVE user overrides ───────────────────────────────────────────────────
  save(language, standards) {
    try {
      const saved = sessionStorage.getItem(this.STORAGE_KEY);
      const all = saved ? JSON.parse(saved) : {};
      all[language] = standards;
      sessionStorage.setItem(this.STORAGE_KEY, JSON.stringify(all));
    } catch(e) {
      console.warn("[CodingStandards] Could not save:", e);
    }
  },

  // ── RESET to defaults ─────────────────────────────────────────────────────
  reset(language) {
    try {
      const saved = sessionStorage.getItem(this.STORAGE_KEY);
      const all = saved ? JSON.parse(saved) : {};
      delete all[language];
      sessionStorage.setItem(this.STORAGE_KEY, JSON.stringify(all));
    } catch(e) {}
    return this.DEFAULTS[language] || this.DEFAULTS["Python"];
  },

  // ── BUILD prompt block for agents ─────────────────────────────────────────
  buildPromptBlock(language, categories) {
    const s = this.get(language);
    const cats = categories || ["naming","structure","errors","security","performance"];
    const lines = ["[CODING STANDARDS — MUST FOLLOW]"];

    const labels = {
      naming:      "📛 Naming Conventions",
      structure:   "🏗️  Code Structure",
      errors:      "⚠️  Error Handling",
      security:    "🔒 Security Rules",
      performance: "⚡ Performance"
    };

    cats.forEach(cat => {
      const rules = s[cat] || [];
      if (!rules.length) return;
      lines.push(`\n${labels[cat]}:`);
      rules.forEach(r => lines.push(`  - ${r}`));
    });

    lines.push("\nThese standards are NON-NEGOTIABLE. Apply them to every line of code.");
    return lines.join("\n");
  }

};