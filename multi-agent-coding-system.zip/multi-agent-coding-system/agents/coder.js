// agents/coder.js
const CoderAgent = {
  name: "Coder",
  icon: "💻",
  MAX_RETRIES: 3,

  async run(plannerData, taskInput, spec, architecture) {
    Storage.appendLog({ agent: this.name, status: "started", subtasks: plannerData.subtasks.length });
    const results = [];
    let previousCode = "";

    for (const subtask of plannerData.subtasks) {
      await sleep(3000);
      Storage.appendLog({ agent: this.name, status: "coding", subtask: subtask.name });

      let attempt = 0;
      let success = false;
      let lastResult = null;

      while (attempt < this.MAX_RETRIES && !success) {
        try {
          const memoryContext = AgentMemory.getContextForAgent("Coder", taskInput.task);
          if (attempt > 0) {
            subtask._retryNote = attempt === 1
              ? "Previous attempt had placeholder code. Write REAL, COMPLETE implementation."
              : "Second retry. Every function MUST have a full working body. No placeholders allowed.";
          }
          const prompt = ContextBuilder.coder(
            subtask, taskInput.language, taskInput.framework,
            taskInput.database, previousCode, spec, architecture, memoryContext
          );
          const raw = await callGroq(prompt.system, prompt.user);
          const data = parseJSON(raw);

          if (!data || !data.code) throw new Error("No code in response");

          // Detect placeholder code
          const placeholderPatterns = [
            /not provided/i, /implement this/i, /add your code/i,
            /coming soon/i, /placeholder/i, /todo:/i, /pass\s*#/i,
            /raise NotImplementedError/i
          ];
          const hasPlaceholder = placeholderPatterns.some(p => p.test(data.code));
          if (hasPlaceholder && attempt < this.MAX_RETRIES - 1) {
            attempt++;
            await sleep(5000);
            continue;
          }

          previousCode = data.code.substring(0, 400);
          lastResult = { subtask_id: subtask.id, success: true, data };
          success = true;

        } catch(err) {
          Storage.appendLog({ agent: this.name, status: "retry", subtask: subtask.name, attempt, error: err.message });
          attempt++;
          if (attempt < this.MAX_RETRIES) await sleep(10000 * attempt);
        }
      }

      if (!success) {
        lastResult = { subtask_id: subtask.id, success: false, error: "Max retries exceeded" };
      }
      results.push(lastResult);
    }

    Storage.appendLog({ agent: this.name, status: "completed", files: results.filter(r => r.success).length });
    return { success: true, data: results };
  }
};