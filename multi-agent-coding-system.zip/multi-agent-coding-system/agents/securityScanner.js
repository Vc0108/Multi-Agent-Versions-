// agents/securityScanner.js
// Security Scanner Agent — scans all generated code for vulnerabilities
// Runs after Debugger, before Documenter

const SecurityScannerAgent = {

  name: "SecurityScanner",
  icon: "🔒",

  // Patterns that indicate security vulnerabilities
  VULNERABILITY_PATTERNS: [
    {
      id: "SEC001",
      name: "Hardcoded Secret",
      severity: "critical",
      pattern: /(secret_key|password|api_key|token)\s*=\s*["'][^"']{3,}["']/gi,
      description: "Hardcoded secret or password found in source code",
      fix: "Move to environment variables using os.getenv() or python-dotenv"
    },
    {
      id: "SEC002",
      name: "No Password Hashing",
      severity: "critical",
      pattern: /password\s*=\s*[\w.]+\.password(?!.*hash|.*bcrypt|.*passlib)/gi,
      description: "Password stored without hashing",
      fix: "Use passlib with bcrypt to hash passwords before storing"
    },
    {
      id: "SEC003",
      name: "SQL Injection Risk",
      severity: "critical",
      pattern: /f["'].*SELECT.*{|execute\(f["']|execute\(".*\+/gi,
      description: "Potential SQL injection via string formatting",
      fix: "Use parameterized queries or SQLAlchemy ORM methods"
    },
    {
      id: "SEC004",
      name: "Missing Auth on Endpoint",
      severity: "high",
      pattern: /@(app|router)\.(put|delete|patch)\([^)]+\)\s*\ndef\s+\w+\s*\([^)]*\)(?!.*Depends)/gi,
      description: "PUT/DELETE/PATCH endpoint missing authentication dependency",
      fix: "Add Depends(get_current_user) parameter to protected endpoints"
    },
    {
      id: "SEC005",
      name: "Weak JWT Algorithm",
      severity: "high",
      pattern: /algorithm\s*=\s*["']none["']|algorithm\s*=\s*["']HS1["']/gi,
      description: "Weak or no JWT signing algorithm",
      fix: "Use HS256 or RS256 for JWT signing"
    },
    {
      id: "SEC006",
      name: "Exposed Stack Trace",
      severity: "medium",
      pattern: /raise\s+HTTPException.*str\(e\)|detail\s*=\s*str\(e\)/gi,
      description: "Exception details exposed in API response",
      fix: "Return generic error messages, log full details server-side"
    },
    {
      id: "SEC007",
      name: "No Input Validation",
      severity: "medium",
      pattern: /def\s+\w+\s*\(\s*\w+\s*:\s*dict\s*\)/gi,
      description: "Endpoint accepting raw dict instead of Pydantic model",
      fix: "Use Pydantic BaseModel for all request bodies"
    },
    {
      id: "SEC008",
      name: "Debug Mode in Production",
      severity: "medium",
      pattern: /debug\s*=\s*True|reload\s*=\s*True/gi,
      description: "Debug or reload mode enabled",
      fix: "Set debug=False in production, use environment variables"
    },
    {
      id: "SEC009",
      name: "No CORS Configuration",
      severity: "low",
      pattern: /FastAPI\(\)/gi,
      description: "No CORS middleware configured",
      fix: "Add CORSMiddleware to restrict which origins can access your API"
    },
    {
      id: "SEC010",
      name: "Sensitive Data in Logs",
      severity: "low",
      pattern: /logging\.(info|debug)\(.*password|print\(.*password/gi,
      description: "Sensitive data being logged",
      fix: "Never log passwords, tokens, or sensitive user data"
    }
  ],

  async run(codeFiles, taskInput) {
    Storage.appendLog({ agent: this.name, status: "started" });

    try {
      // Run static analysis on all generated code (no AI needed — pure pattern matching)
      const allFindings = [];
      const fileResults = [];

      codeFiles.forEach(fileResult => {
        if (!fileResult.success || !fileResult.data) return;

        const code = fileResult.data.final_code || fileResult.data.code || "";
        const filename = fileResult.data.filename || "unknown.py";
        const findings = this._scanCode(code, filename);

        fileResults.push({
          filename,
          subtask_name: fileResult.data.subtask_name,
          findings,
          is_clean: findings.length === 0,
          risk_level: this._calculateRiskLevel(findings)
        });

        allFindings.push(...findings);
      });

      // Aggregate results
      const summary = this._buildSummary(allFindings, fileResults);

      // Get AI recommendations for critical issues
      const criticalIssues = allFindings.filter(f => f.severity === "critical");
      let aiRecommendations = [];
      if (criticalIssues.length > 0) {
        await sleep(3000);
        aiRecommendations = await this._getAIRecommendations(criticalIssues, taskInput);
      }

      const result = {
        summary,
        file_results: fileResults,
        all_findings: allFindings,
        ai_recommendations: aiRecommendations,
        critical_count: allFindings.filter(f => f.severity === "critical").length,
        high_count: allFindings.filter(f => f.severity === "high").length,
        medium_count: allFindings.filter(f => f.severity === "medium").length,
        low_count: allFindings.filter(f => f.severity === "low").length,
        overall_risk: summary.overall_risk,
        is_safe: summary.overall_risk === "low" || summary.overall_risk === "none",
        scanned_files: fileResults.length,
        scanned_at: new Date().toISOString()
      };

      Storage.appendLog({
        agent: this.name,
        status: "completed",
        risk: summary.overall_risk,
        findings: allFindings.length
      });

      return { success: true, data: result };

    } catch (err) {
      Storage.appendLog({ agent: this.name, status: "error", error: err.message });
      return {
        success: false,
        data: this._buildEmptyResult(),
        error: err.message
      };
    }
  },

  // ── STATIC CODE SCANNER ───────────────────────────────────────────────────
  _scanCode(code, filename) {
    const findings = [];

    this.VULNERABILITY_PATTERNS.forEach(vuln => {
      // Reset regex lastIndex for global patterns
      vuln.pattern.lastIndex = 0;
      const matches = code.match(vuln.pattern);
      if (matches) {
        // Find approximate line numbers
        const lines = code.split("\n");
        const lineNumbers = [];
        lines.forEach((line, idx) => {
          vuln.pattern.lastIndex = 0;
          if (vuln.pattern.test(line)) lineNumbers.push(idx + 1);
        });
        vuln.pattern.lastIndex = 0;

        findings.push({
          rule_id: vuln.id,
          name: vuln.name,
          severity: vuln.severity,
          description: vuln.description,
          fix: vuln.fix,
          filename,
          line_numbers: lineNumbers,
          occurrences: matches.length
        });
      }
    });

    return findings;
  },

  // ── CALCULATE RISK LEVEL for a file ──────────────────────────────────────
  _calculateRiskLevel(findings) {
    if (findings.some(f => f.severity === "critical")) return "critical";
    if (findings.some(f => f.severity === "high"))     return "high";
    if (findings.some(f => f.severity === "medium"))   return "medium";
    if (findings.some(f => f.severity === "low"))      return "low";
    return "none";
  },

  // ── BUILD SUMMARY ─────────────────────────────────────────────────────────
  _buildSummary(allFindings, fileResults) {
    const criticalCount = allFindings.filter(f => f.severity === "critical").length;
    const highCount     = allFindings.filter(f => f.severity === "high").length;
    const cleanFiles    = fileResults.filter(f => f.is_clean).length;

    let overall_risk = "none";
    if (criticalCount > 0)      overall_risk = "critical";
    else if (highCount > 0)     overall_risk = "high";
    else if (allFindings.some(f => f.severity === "medium")) overall_risk = "medium";
    else if (allFindings.length > 0) overall_risk = "low";

    return {
      overall_risk,
      total_findings: allFindings.length,
      clean_files: cleanFiles,
      total_files: fileResults.length,
      top_issues: allFindings
        .filter(f => ["critical","high"].includes(f.severity))
        .slice(0,3)
        .map(f => `${f.rule_id}: ${f.name} in ${f.filename}`)
    };
  },

  // ── GET AI RECOMMENDATIONS for critical issues ────────────────────────────
  async _getAIRecommendations(criticalIssues, taskInput) {
    try {
      const issueList = criticalIssues.slice(0,3).map(i =>
        `- ${i.name}: ${i.description} (in ${i.filename})`
      ).join("\n");

      const raw = await callGroq(
        `You are a security expert. Give concise, actionable fixes. Respond with ONLY a JSON array.`,
        `These critical security issues were found in ${taskInput.framework} code:\n${issueList}\n\nRespond with ONLY a JSON array of fix recommendations:\n[\n  {\n    "issue": "Issue name",\n    "priority": "Fix immediately",\n    "code_fix": "Short code example showing the fix",\n    "explanation": "Why this is dangerous and how the fix helps"\n  }\n]`
      );

      const parsed = parseJSON(raw);
      return Array.isArray(parsed) ? parsed : [];
    } catch(e) {
      return [];
    }
  },

  // ── EMPTY RESULT (on error) ───────────────────────────────────────────────
  _buildEmptyResult() {
    return {
      summary: { overall_risk: "unknown", total_findings: 0 },
      file_results: [],
      all_findings: [],
      ai_recommendations: [],
      critical_count: 0,
      high_count: 0,
      medium_count: 0,
      low_count: 0,
      overall_risk: "unknown",
      is_safe: false,
      scanned_files: 0,
      scanned_at: new Date().toISOString()
    };
  }

};