// agents/debugger.js
const DebuggerAgent = {
  name: "Debugger",
  icon: "🔧",
  MAX_LOOPS: 2,

  async run(testerOutputs, taskInput) {
    Storage.appendLog({ agent: this.name, status: "started" });
    const results = [];

    for (const testResult of testerOutputs) {
      if (!testResult.success || !testResult.data) {
        results.push(testResult);
        continue;
      }

      const data = testResult.data;
      if (!data.needs_debug) {
        results.push({
          subtask_id: testResult.subtask_id,
          success: true,
          data: { ...data, debug_loops: 0, fixes_applied: [], verdict: "PASS" }
        });
        continue;
      }

      // Needs debugging
      let code = data.final_code || "";
      const failedTests = (data.test_cases || []).filter(t => t.status === "FAIL");
      const fixesApplied = [];
      let debugLoops = 0;
      let finalVerdict = "FAIL";

      for (let loop = 0; loop < this.MAX_LOOPS; loop++) {
        await sleep(3000);
        debugLoops++;
        try {
          const memoryContext = AgentMemory.getContextForAgent("Debugger", taskInput.task);
          const prompt = ContextBuilder.debuggerPrompt(
            data.subtask_name, code,
            failedTests.map(t => t.failure_reason).join("; "),
            failedTests, fixesApplied
          );
          if (memoryContext) prompt.system += "\n" + memoryContext;

          const raw = await callGroq(prompt.system, prompt.user);
          const parsed = parseJSON(raw);

          if (parsed && parsed.fixed_code && parsed.fixed_code.length > 50) {
            code = parsed.fixed_code;
            fixesApplied.push(parsed.fix_applied || "Applied fix");
            finalVerdict = parsed.confidence === "high" ? "PASS" : "PARTIAL";
            Storage.appendLog({ agent: this.name, status: "fix_applied", loop, subtask: data.subtask_name });
            if (finalVerdict === "PASS") break;
          }
        } catch(err) {
          Storage.appendLog({ agent: this.name, status: "debug_error", error: err.message });
          if (loop < this.MAX_LOOPS - 1) await sleep(15000);
        }
      }

      results.push({
        subtask_id: testResult.subtask_id,
        success: true,
        data: {
          ...data,
          final_code: code,
          debug_loops: debugLoops,
          fixes_applied: fixesApplied,
          verdict: finalVerdict
        }
      });
    }

    Storage.appendLog({ agent: this.name, status: "completed" });
    return { success: true, data: results };
  }
};