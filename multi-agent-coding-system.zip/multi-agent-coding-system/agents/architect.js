// agents/architect.js
// Architecture Agent — designs system architecture before coding
// Uses the spec to produce a concrete technical blueprint

const ArchitectAgent = {

  name: "Architect",
  icon: "🏛️",

  async run(spec, plannerData, taskInput) {
    Storage.appendLog({ agent: this.name, status: "started" });

    try {
      await sleep(3000); // rate limit
      const memoryContext = AgentMemory.getContextForAgent("Architect", taskInput.task);
      const prompt = this._buildPrompt(spec, plannerData, taskInput, memoryContext);
      const raw = await callGroq(prompt.system, prompt.user);
      const architecture = parseJSON(raw);

      if (!architecture || !architecture.components) {
        throw new Error("Architect returned invalid architecture");
      }

      Storage.appendLog({ agent: this.name, status: "completed", components: architecture.components.length });
      return { success: true, data: architecture };

    } catch (err) {
      Storage.appendLog({ agent: this.name, status: "error", error: err.message });
      const fallback = this._buildFallbackArchitecture(spec, taskInput);
      return { success: true, data: fallback, warning: err.message };
    }
  },

  // ── BUILD PROMPT ──────────────────────────────────────────────────────────
  _buildPrompt(spec, plannerData, taskInput, memoryContext) {
    const endpointList = (spec.endpoints || [])
      .map(e => `${e.method} ${e.path} — ${e.description}`)
      .join("\n");

    const subtaskList = (plannerData.subtasks || [])
      .map(s => `#${s.id}: ${s.name}`)
      .join("\n");

    return {
      system: `You are a senior software architect. Design clear, practical system architectures.
CRITICAL: Respond with ONLY a JSON object. Start with { and end with }. No text before or after.
${memoryContext ? `\n${memoryContext}` : ""}`,

      user: `Design the system architecture for this project.

PROJECT: ${taskInput.task}
LANGUAGE: ${taskInput.language}
FRAMEWORK: ${taskInput.framework}
STORAGE: ${spec.storage_type || "in-memory"}

ENDPOINTS TO IMPLEMENT:
${endpointList}

SUBTASKS FROM PLANNER:
${subtaskList}

Respond with ONLY this JSON:
{
  "architecture_pattern": "Layered MVC",
  "summary": "One paragraph describing the overall architecture",
  "components": [
    {
      "name": "AuthModule",
      "file": "auth.py",
      "responsibility": "Handles JWT token creation and validation",
      "depends_on": [],
      "exposes": ["create_token()", "verify_token()", "hash_password()"],
      "endpoints": ["POST /users/login", "POST /users/register"]
    },
    {
      "name": "UserModule",
      "file": "users.py",
      "responsibility": "User management and profile operations",
      "depends_on": ["AuthModule"],
      "exposes": ["get_user()", "update_user()", "delete_user()"],
      "endpoints": ["GET /users/{id}", "PUT /users/{id}"]
    }
  ],
  "data_flow": [
    "Request → Router → Business Logic → In-Memory Store → Response",
    "Auth: Request → JWT Middleware → Route Handler → Response"
  ],
  "file_structure": [
    "main.py — FastAPI app entry point, router registration",
    "auth.py — JWT utilities and password hashing",
    "models.py — Pydantic request/response models",
    "storage.py — In-memory data stores"
  ],
  "coding_guidelines": [
    "Use APIRouter for each module",
    "All endpoints must have Pydantic request/response models",
    "Store all data in module-level dictionaries",
    "Use python-jose for JWT operations",
    "Use passlib for password hashing"
  ],
  "security_considerations": [
    "Hash all passwords with bcrypt before storage",
    "Validate JWT on every protected endpoint",
    "Return 401 for invalid/expired tokens",
    "Never return password hashes in responses"
  ]
}`
    };
  },

  // ── FALLBACK ARCHITECTURE ─────────────────────────────────────────────────
  _buildFallbackArchitecture(spec, taskInput) {
    const components = [];

    // Generate components from spec endpoints
    const endpointGroups = {};
    (spec.endpoints || []).forEach(ep => {
      const group = ep.path.split("/")[1] || "root";
      if (!endpointGroups[group]) endpointGroups[group] = [];
      endpointGroups[group].push(`${ep.method} ${ep.path}`);
    });

    Object.entries(endpointGroups).forEach(([group, endpoints]) => {
      components.push({
        name: group.charAt(0).toUpperCase() + group.slice(1) + "Module",
        file: `${group}.py`,
        responsibility: `Handles ${group} operations`,
        depends_on: [],
        exposes: [],
        endpoints
      });
    });

    return {
      architecture_pattern: "Layered MVC",
      summary: `${taskInput.framework} application with in-memory storage and JWT authentication`,
      components,
      data_flow: ["Request → Router → Handler → In-Memory Store → Response"],
      file_structure: components.map(c => `${c.file} — ${c.responsibility}`),
      coding_guidelines: [
        "Use APIRouter for each module",
        "All endpoints must have Pydantic models",
        "Store data in module-level dictionaries"
      ],
      security_considerations: [
        "Hash passwords with bcrypt",
        "Validate JWT on protected routes"
      ],
      _isFallback: true
    };
  }

};