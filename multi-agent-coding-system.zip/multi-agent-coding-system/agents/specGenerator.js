// agents/specGenerator.js
// Spec Generator Agent — Agent 0
// Converts user task description into a formal JSON specification
// This spec is passed to ALL other agents as a shared contract

const SpecGeneratorAgent = {

  name: "SpecGenerator",
  icon: "📐",

  async run(taskInput) {
    Storage.appendLog({ agent: this.name, status: "started", task: taskInput.task });

    try {
      const memoryContext = AgentMemory.getContextForAgent("SpecGenerator", taskInput.task);
      const prompt = this._buildPrompt(taskInput, memoryContext);
      const raw = await callGroq(prompt.system, prompt.user);
      const spec = parseJSON(raw);

      if (!spec || !spec.endpoints) {
        throw new Error("Spec Generator returned invalid spec — missing endpoints");
      }

      // Enrich spec with metadata
      spec.generated_at = new Date().toISOString();
      spec.task_original = taskInput.task;
      spec.language = taskInput.language;
      spec.framework = taskInput.framework;
      spec.database = taskInput.database;

      Storage.appendLog({ agent: this.name, status: "completed", endpointCount: spec.endpoints.length });
      return { success: true, data: spec };

    } catch (err) {
      Storage.appendLog({ agent: this.name, status: "error", error: err.message });

      // Return a minimal fallback spec so pipeline can continue
      const fallback = this._buildFallbackSpec(taskInput);
      return { success: true, data: fallback, warning: err.message };
    }
  },

  // ── BUILD PROMPT ──────────────────────────────────────────────────────────
  _buildPrompt(taskInput, memoryContext) {
    return {
      system: `You are a software specification expert. Convert project requirements into a precise formal specification.
CRITICAL: Respond with ONLY a JSON object. Start with { and end with }. No text before or after.
${memoryContext ? `\n${memoryContext}` : ""}`,

      user: `Generate a complete formal specification for this project.

PROJECT: ${taskInput.task}
LANGUAGE: ${taskInput.language}
FRAMEWORK: ${taskInput.framework}
DATABASE: ${taskInput.database}
COMPLEXITY: ${taskInput.complexity}
CONSTRAINTS: ${taskInput.constraints || "None"}

Respond with ONLY this JSON:
{
  "project_name": "Short project name",
  "description": "One sentence description of what this project does",
  "auth_required": true,
  "auth_type": "JWT",
  "storage_type": "in-memory",
  "endpoints": [
    {
      "id": 1,
      "method": "POST",
      "path": "/users/register",
      "description": "Register a new user",
      "auth_required": false,
      "request_body": {
        "username": "string",
        "password": "string",
        "email": "string"
      },
      "response": {
        "user_id": "string",
        "message": "string"
      },
      "business_rules": [
        "username must be unique",
        "password must be at least 8 characters"
      ],
      "error_responses": [
        {"status": 400, "condition": "username already exists"},
        {"status": 422, "condition": "invalid input format"}
      ]
    }
  ],
  "data_models": [
    {
      "name": "User",
      "fields": {
        "user_id": "str (UUID)",
        "username": "str",
        "password_hash": "str",
        "created_at": "datetime",
        "is_online": "bool"
      }
    }
  ],
  "business_rules": [
    "All protected endpoints require valid JWT token",
    "Passwords must be hashed before storage"
  ],
  "features": [
    "User registration and login",
    "JWT authentication",
    "In-memory storage"
  ],
  "non_functional": {
    "performance": "All endpoints respond under 200ms",
    "security": "Passwords hashed with bcrypt",
    "scalability": "In-memory storage supports up to 1000 concurrent users"
  }
}`
    };
  },

  // ── FALLBACK SPEC when AI fails ───────────────────────────────────────────
  _buildFallbackSpec(taskInput) {
    return {
      project_name: taskInput.task.split(" ").slice(0,3).join(" "),
      description: taskInput.task,
      auth_required: true,
      auth_type: "JWT",
      storage_type: "in-memory",
      language: taskInput.language,
      framework: taskInput.framework,
      database: taskInput.database,
      endpoints: [
        {
          id: 1,
          method: "POST",
          path: "/users/register",
          description: "Register a new user",
          auth_required: false,
          request_body: { username: "string", password: "string" },
          response: { user_id: "string", message: "string" },
          business_rules: ["username must be unique"],
          error_responses: [{ status: 400, condition: "username already exists" }]
        },
        {
          id: 2,
          method: "POST",
          path: "/users/login",
          description: "Login and get JWT token",
          auth_required: false,
          request_body: { username: "string", password: "string" },
          response: { access_token: "string", token_type: "bearer" },
          business_rules: ["return JWT on success"],
          error_responses: [{ status: 401, condition: "invalid credentials" }]
        }
      ],
      data_models: [],
      business_rules: ["JWT required for protected routes"],
      features: [taskInput.task],
      non_functional: {},
      generated_at: new Date().toISOString(),
      task_original: taskInput.task,
      _isFallback: true
    };
  }

};