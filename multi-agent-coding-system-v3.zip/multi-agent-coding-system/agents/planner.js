// agents/planner.js
const PlannerAgent = {
  name: "Planner",
  icon: "🧭",

  async run(taskInput, spec) {
    Storage.appendLog({ agent: this.name, status: "started" });
    try {
      const memoryContext = AgentMemory.getContextForAgent("Planner", taskInput.task);
      const prompt = ContextBuilder.planner(
        taskInput.task, taskInput.language, taskInput.framework,
        taskInput.database, taskInput.complexity, taskInput.constraints,
        spec
      );
      if (memoryContext) prompt.system += "\n" + memoryContext;

      const raw = await callGroq(prompt.system, prompt.user);
      const data = parseJSON(raw);
      if (!data || !data.subtasks) throw new Error("Invalid planner response — missing subtasks");
      Storage.appendLog({ agent: this.name, status: "completed", subtasks: data.subtasks.length });
      return { success: true, data };
    } catch(err) {
      Storage.appendLog({ agent: this.name, status: "error", error: err.message });
      return { success: false, error: err.message };
    }
  }
};
