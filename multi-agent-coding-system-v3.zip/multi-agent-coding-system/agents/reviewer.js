// agents/reviewer.js
const ReviewerAgent = {
  name: "Reviewer",
  icon: "🔍",

  async run(coderOutputs, plannerData, taskInput, spec) {
    Storage.appendLog({ agent: this.name, status: "started" });
    const results = [];

    for (const codeResult of coderOutputs) {
      if (!codeResult.success || !codeResult.data) {
        results.push({ subtask_id: codeResult.subtask_id, success: false, data: null });
        continue;
      }
      await sleep(3000);

      // Default to PASS before calling AI
      let reviewData = {
        subtask_name: codeResult.data.subtask_name,
        filename: codeResult.data.filename,
        verdict: "PASS",
        score: 80,
        issues: [],
        strengths: ["Code generated successfully"],
        revised_code: codeResult.data.code,
        retries_needed: 0
      };

      try {
        const prompt = ContextBuilder.reviewer(
          codeResult.data.subtask_name, codeResult.data.code,
          taskInput.language, spec
        );
        const raw = await callGroq(prompt.system, prompt.user);
        const parsed = parseJSON(raw);

        if (parsed && parsed.verdict) {
          // Override fake score=60 with no issues
          if (parsed.score === 60 && (!parsed.issues || parsed.issues.length === 0)) {
            parsed.verdict = "PASS";
            parsed.score = 75;
          }
          // Only use revised_code if substantial
          if (parsed.revised_code && parsed.revised_code.length > 50 &&
              !/not provided|placeholder|implement/i.test(parsed.revised_code)) {
            reviewData.revised_code = parsed.revised_code;
          }
          reviewData = { ...reviewData, ...parsed, revised_code: reviewData.revised_code };
        }
      } catch(err) {
        Storage.appendLog({ agent: this.name, status: "review_error", error: err.message });
        // Keep default PASS
      }

      // Attach final code
      reviewData.final_code = reviewData.revised_code || codeResult.data.code;
      reviewData.filename = reviewData.filename || codeResult.data.filename;

      results.push({ subtask_id: codeResult.subtask_id, success: true, data: reviewData });
    }

    Storage.appendLog({ agent: this.name, status: "completed" });
    return { success: true, data: results };
  }
};
