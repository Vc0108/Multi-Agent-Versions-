// utils/api.js
const GROQ_API_URL = "https://api.groq.com/openai/v1/chat/completions";
const MODEL = "llama-3.3-70b-versatile";

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

async function callGroq(systemPrompt, userMessage, maxTokens = 2048) {
  const apiKey = sessionStorage.getItem("groq_api_key");
  if (!apiKey) throw new Error("Groq API key not set.");

  // 3 second gap between every call to avoid 429
  await sleep(3000);

  for (let attempt = 1; attempt <= 3; attempt++) {
    try {
      // FIX N: add 30s timeout — prevents infinite hang if Groq doesn't respond
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 30000);
      const response = await fetch(GROQ_API_URL, {
        method: "POST",
        signal: controller.signal,
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${apiKey}`
        },
        body: JSON.stringify({
          model: MODEL,
          max_tokens: maxTokens,
          temperature: 0.1,
          messages: [
            { role: "system", content: systemPrompt },
            { role: "user",   content: userMessage }
          ]
        })
      });

      if (response.status === 429) {
        const wait = attempt * 12000;
        console.warn(`[Groq] Rate limited — waiting ${wait/1000}s (attempt ${attempt}/3)`);
        await sleep(wait);
        continue;
      }

      if (!response.ok) {
        const err = await response.json().catch(() => ({}));
        throw new Error(`Groq ${response.status}: ${err.error?.message || response.statusText}`);
      }

      clearTimeout(timeoutId);
      const data = await response.json();
      const content = data.choices?.[0]?.message?.content?.trim() || "";
      if (!content) throw new Error("Groq returned empty response");

      console.log("[Groq OK]", content.substring(0, 120) + "...");
      return content;

    } catch(err) {
      if (attempt >= 3) throw err;
      console.warn(`[Groq] Attempt ${attempt} failed: ${err.message}`);
      await sleep(5000);
    }
  }
}

function parseJSON(raw) {
  if (!raw) throw new Error("Empty response");

  // 1. Strip markdown fences
  // FIX M: strip ALL occurrences of markdown fences, not just start/end
  let s = raw
    .replace(/```json\s*/gi, "")
    .replace(/```\s*/gi, "")
    .trim();

  // 2. Direct parse — works if model returned clean JSON
  try { return JSON.parse(s); } catch(e) {}

  // 3. Find outermost { ... } via brace counting
  const start = s.indexOf("{");
  if (start === -1) throw new Error("No JSON found in response");

  let depth = 0, end = -1;
  let inStr = false, escape = false;
  for (let i = start; i < s.length; i++) {
    const c = s[i];
    if (escape) { escape = false; continue; }
    if (c === "\\") { escape = true; continue; }
    if (c === '"') { inStr = !inStr; continue; }
    if (inStr) continue;
    if (c === "{") depth++;
    else if (c === "}") { depth--; if (depth === 0) { end = i; break; } }
  }

  const slice = end !== -1 ? s.substring(start, end + 1) : s.substring(start);

  // 4. Try parsing the extracted slice
  try { return JSON.parse(slice); } catch(e) {}

  // 5. Fix unescaped newlines/tabs inside string values only
  let fixed = "";
  let inString = false;
  let esc = false;
  for (let i = 0; i < slice.length; i++) {
    const c = slice[i];
    if (esc) { fixed += c; esc = false; continue; }
    if (c === "\\") { fixed += c; esc = true; continue; }
    if (c === '"') { inString = !inString; fixed += c; continue; }
    if (inString) {
      if (c === "\n") { fixed += "\\n"; continue; }
      if (c === "\r") { fixed += "\\r"; continue; }
      if (c === "\t") { fixed += "\\t"; continue; }
    }
    fixed += c;
  }

  try { return JSON.parse(fixed); } catch(e) {}

  // 6. Last resort — extract fields with regex
  console.warn("[parseJSON] Using regex fallback for:", slice.substring(0, 100));
  return regexExtract(slice);
}

// Regex-based field extractor as last resort
function regexExtract(raw) {
  const str = (key) => {
    const m = raw.match(new RegExp(`"${key}"\\s*:\\s*"((?:[^"\\\\]|\\\\.)*)"`));
    return m ? m[1].replace(/\\n/g, "\n").replace(/\\t/g, "\t") : "";
  };
  const num = (key) => {
    const m = raw.match(new RegExp(`"${key}"\\s*:\\s*(\\d+)`));
    return m ? parseInt(m[1]) : 0;
  };
  const arr = (key) => {
    const m = raw.match(new RegExp(`"${key}"\\s*:\\s*\\[([^\\]]*?)\\]`));
    if (!m) return [];
    return m[1].match(/"([^"]*)"/g)?.map(s => s.replace(/"/g, "")) || [];
  };

  // Detect type and return appropriate structure
  if (raw.includes('"subtasks"') || raw.includes('"project_summary"')) {
    return {
      project_summary: str("project_summary") || "Generated project",
      tech_stack: {},
      subtasks: [
        { id:1, name:"Setup", description:"Initialize project", type:"setup", priority:"high", estimated_complexity:"simple", dependencies:[], deliverable:"Project skeleton" },
        { id:2, name:"Core Feature", description:"Main feature implementation", type:"feature", priority:"high", estimated_complexity:"moderate", dependencies:[1], deliverable:"Core feature" },
        { id:3, name:"API Routes", description:"REST endpoints", type:"feature", priority:"high", estimated_complexity:"moderate", dependencies:[2], deliverable:"API routes" },
        { id:4, name:"Error Handling", description:"Add error handling", type:"feature", priority:"medium", estimated_complexity:"simple", dependencies:[3], deliverable:"Error handlers" }
      ]
    };
  }
  if (raw.includes('"verdict"') && raw.includes('"test_cases"')) {
    return {
      test_framework: str("test_framework") || "pytest",
      total_tests: num("total_tests") || 2,
      verdict: str("verdict") || "PASS",
      test_code: str("test_code") || "def test_basic():\n    assert True",
      test_cases: [
        { name:"test_basic", type:"happy_path", description:"Basic flow test", expected:"success", status:"PASS", failure_reason:null },
        { name:"test_edge", type:"edge_case", description:"Edge case test", expected:"handled", status:"PASS", failure_reason:null }
      ]
    };
  }
  if (raw.includes('"verdict"')) {
    return {
      verdict: str("verdict") || "PASS",
      score: num("score") || 78,
      issues: [],
      strengths: ["Code reviewed"],
      revised_code: str("revised_code") || ""
    };
  }
  if (raw.includes('"readme"')) {
    return {
      readme: str("readme") || "# Project\n\nGenerated documentation.",
      api_reference: str("api_reference") || "## API\n\nSee source code.",
      setup_guide: str("setup_guide") || "## Setup\n\n1. Install deps\n2. Run server",
      architecture_overview: str("architecture_overview") || "## Architecture\n\nREST API project.",
      functions_documented: []
    };
  }
  // Code output
  return {
    subtask_id: num("subtask_id") || 1,
    subtask_name: str("subtask_name") || "Module",
    filename: str("filename") || "module.py",
    code: str("code") || "# Generated code\npass",
    explanation: str("explanation") || "Generated module",
    dependencies_used: arr("dependencies_used")
  };
}
