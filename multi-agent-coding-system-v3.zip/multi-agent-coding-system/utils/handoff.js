// utils/handoff.js
// Task Handoff Tracker — makes data passing between agents explicit and traceable
// Every time one agent passes data to the next, it is logged here with full context

const TaskHandoff = {

  STORAGE_KEY: "taskHandoffs_v1",
  handoffs: [],

  // ── HANDOFF DEFINITIONS — what each agent receives and what it passes on ──
  PIPELINE: [
    {
      from: "User",
      to: "Spec Generator",
      passing: ["task_description", "language", "framework", "database", "complexity", "constraints"],
      purpose: "Convert natural language task into a formal specification"
    },
    {
      from: "Spec Generator",
      to: "Planner",
      passing: ["spec.endpoints", "spec.data_models", "spec.business_rules", "spec.features", "spec.auth_type"],
      purpose: "Use the formal spec to break work into structured subtasks"
    },
    {
      from: "Planner",
      to: "Architect",
      passing: ["planner.subtasks", "planner.project_summary", "planner.tech_stack", "spec (full)"],
      purpose: "Design the file structure and component architecture for the planned subtasks"
    },
    {
      from: "Architect",
      to: "Coder",
      passing: ["architect.components", "architect.file_structure", "architect.coding_guidelines", "planner.subtasks", "spec (full)"],
      purpose: "Write complete code for each subtask following the architecture and spec"
    },
    {
      from: "Coder",
      to: "Reviewer",
      passing: ["coder[].filename", "coder[].code", "coder[].explanation", "spec.business_rules", "coding_standards"],
      purpose: "Review each file for bugs, standards violations, and spec compliance"
    },
    {
      from: "Reviewer",
      to: "Tester",
      passing: ["reviewer[].revised_code", "reviewer[].verdict", "reviewer[].score", "reviewer[].needs_debug"],
      purpose: "Generate test cases and pytest code for each reviewed file"
    },
    {
      from: "Tester",
      to: "Debugger",
      passing: ["tester[].test_cases (failing only)", "tester[].needs_debug files", "original code"],
      purpose: "Fix only the files that failed testing — skip all passing files"
    },
    {
      from: "Debugger",
      to: "Security Scanner",
      passing: ["all final code (fixed + passing)", "all filenames"],
      purpose: "Scan all final code for 10 security vulnerability patterns"
    },
    {
      from: "Security Scanner",
      to: "Documenter",
      passing: ["all final code", "spec (full)", "security.findings", "tech_stack"],
      purpose: "Generate README, API reference, setup guide, and architecture overview"
    }
  ],

  // ── RECORD A HANDOFF ──────────────────────────────────────────────────────
  record(fromAgent, toAgent, payload) {
    // Summarise the payload (don't store full code — just metadata)
    const summary = this._summarisePayload(fromAgent, payload);

    const handoff = {
      id: this.handoffs.length + 1,
      from: fromAgent,
      to: toAgent,
      timestamp: new Date().toISOString(),
      summary,
      payload_size: JSON.stringify(payload || {}).length,
      status: "delivered"
    };

    this.handoffs.push(handoff);
    this._saveToStorage();

    Storage.appendLog({
      agent: fromAgent,
      status: "handoff",
      to: toAgent,
      summary: summary.description
    });

    console.log(`[TaskHandoff] ${fromAgent} → ${toAgent}: ${summary.description}`);
    return handoff;
  },

  // ── SUMMARISE WHAT IS BEING PASSED ────────────────────────────────────────
  _summarisePayload(fromAgent, payload) {
    if (!payload) return { description: "No data passed", items: [] };

    const items = [];
    let description = "";

    switch(fromAgent) {
      case "User":
        description = `Task: "${(payload.task||"").substring(0,60)}..." | ${payload.language} / ${payload.framework}`;
        items.push(`Language: ${payload.language}`);
        items.push(`Framework: ${payload.framework}`);
        items.push(`Database: ${payload.database}`);
        items.push(`Complexity: ${payload.complexity}`);
        break;

      case "Spec Generator":
        const epCount = (payload.endpoints||[]).length;
        const modelCount = (payload.data_models||[]).length;
        description = `${epCount} endpoints, ${modelCount} data models, auth: ${payload.auth_type||"none"}`;
        items.push(`Endpoints: ${epCount}`);
        items.push(`Data Models: ${modelCount}`);
        items.push(`Auth Type: ${payload.auth_type||"none"}`);
        items.push(`Business Rules: ${(payload.business_rules||[]).length}`);
        items.push(`Features: ${(payload.features||[]).length}`);
        break;

      case "Planner":
        const taskCount = (payload.subtasks||[]).length;
        description = `${taskCount} subtasks planned for ${payload.project_summary||"project"}`;
        (payload.subtasks||[]).forEach(t => items.push(`Subtask ${t.id}: ${t.name} [${t.priority}]`));
        break;

      case "Architect":
        const compCount = (payload.components||[]).length;
        const fileCount = (payload.file_structure||[]).length;
        description = `${compCount} components, ${fileCount} files planned`;
        items.push(`Components: ${compCount}`);
        items.push(`File Structure: ${fileCount} files`);
        items.push(`Coding Guidelines: ${(payload.coding_guidelines||[]).length}`);
        items.push(`Security Notes: ${(payload.security_considerations||[]).length}`);
        break;

      case "Coder":
        const files = Array.isArray(payload) ? payload : [];
        const successFiles = files.filter(f => f.success);
        description = `${successFiles.length}/${files.length} files written`;
        successFiles.forEach(f => {
          if(f.data) items.push(`${f.data.filename} — ${(f.data.code||"").split("\n").length} lines`);
        });
        break;

      case "Reviewer":
        const reviewed = Array.isArray(payload) ? payload : [];
        const passCount = reviewed.filter(r => r.data && r.data.verdict === "PASS").length;
        const avgScore = reviewed.length
          ? Math.round(reviewed.reduce((a,r) => a + (r.data && r.data.score ? r.data.score : 0), 0) / reviewed.length)
          : 0;
        description = `${passCount}/${reviewed.length} files passed, avg score ${avgScore}`;
        reviewed.forEach(r => {
          if(r.data) items.push(`${r.data.filename}: ${r.data.verdict} (${r.data.score}/100)`);
        });
        break;

      case "Tester":
        const tested = Array.isArray(payload) ? payload : [];
        const needDebug = tested.filter(t => t.data && t.data.needs_debug).length;
        const totalTests = tested.reduce((a,t) => a + ((t.data&&t.data.test_cases)||[]).length, 0);
        description = `${totalTests} test cases generated, ${needDebug} files need debug`;
        items.push(`Total tests: ${totalTests}`);
        items.push(`Files needing debug: ${needDebug}`);
        break;

      case "Debugger":
        const debugged = Array.isArray(payload) ? payload : [];
        description = `${debugged.length} files debugged and fixed`;
        debugged.forEach(d => {
          if(d.data) items.push(`${d.data.filename}: ${d.data.confidence} confidence fix`);
        });
        break;

      case "Security Scanner":
        if(payload && payload.findings !== undefined) {
          description = `${payload.total_findings} findings, overall risk: ${payload.overall_risk}`;
          items.push(`Risk Level: ${payload.overall_risk}`);
          items.push(`Files Scanned: ${payload.files_scanned}`);
          items.push(`Total Findings: ${payload.total_findings}`);
        }
        break;

      default:
        description = "Data passed";
        items.push(`Payload size: ${JSON.stringify(payload||{}).length} chars`);
    }

    return { description, items };
  },

  // ── GET FULL HANDOFF CHAIN FOR UI ─────────────────────────────────────────
  getChain() {
    return this.handoffs;
  },

  // ── GET PIPELINE DEFINITION (static) ──────────────────────────────────────
  getPipelineDefinition() {
    return this.PIPELINE;
  },

  // ── BUILD HANDOFF SUMMARY FOR A SPECIFIC AGENT ────────────────────────────
  getHandoffContext(agentName) {
    // Returns a string showing what was handed to this agent
    const incoming = this.handoffs.find(h => h.to === agentName);
    if (!incoming) return "";

    return `[TASK HANDOFF from ${incoming.from}]
What was passed to you: ${incoming.summary.description}
Details:
${incoming.summary.items.map(i => "  - " + i).join("\n")}`;
  },

  // ── CLEAR ALL ─────────────────────────────────────────────────────────────
  clear() {
    this.handoffs = [];
    try { sessionStorage.removeItem(this.STORAGE_KEY); } catch(e) {}
  },

  // ── STORAGE ───────────────────────────────────────────────────────────────
  _saveToStorage() {
    try {
      sessionStorage.setItem(this.STORAGE_KEY, JSON.stringify(this.handoffs.slice(-20)));
    } catch(e) {}
  },

  _loadFromStorage() {
    try {
      const saved = sessionStorage.getItem(this.STORAGE_KEY);
      if (saved) this.handoffs = JSON.parse(saved);
    } catch(e) {}
  }
};

// Load on init
TaskHandoff._loadFromStorage();
