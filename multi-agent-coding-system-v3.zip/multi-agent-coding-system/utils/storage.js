// utils/storage.js
// Session storage — manages state across agents in a single run

const Storage = {

  // ── SAVE / LOAD SESSION ────────────────────────────────────────────────────
  saveSession(data) {
    sessionStorage.setItem("mas_session", JSON.stringify(data));
  },

  loadSession() {
    try {
      const raw = sessionStorage.getItem("mas_session");
      return raw ? JSON.parse(raw) : null;
    } catch(e) { return null; }
  },

  clearSession() {
    sessionStorage.removeItem("mas_session");
  },

  // ── API KEY ────────────────────────────────────────────────────────────────
  saveApiKey(key) {
    sessionStorage.setItem("groq_api_key", key);
  },

  getApiKey() {
    return sessionStorage.getItem("groq_api_key");
  },

  clearApiKey() {
    sessionStorage.removeItem("groq_api_key");
  },

  // ── GEMINI API KEY (for cross-LLM evaluation) ─────────────────────────────
  saveGeminiKey(key) {
    sessionStorage.setItem("gemini_api_key", key);
  },

  getGeminiKey() {
    return sessionStorage.getItem("gemini_api_key");
  },

  clearGeminiKey() {
    sessionStorage.removeItem("gemini_api_key");
  },

  // ── AGENT OUTPUTS ──────────────────────────────────────────────────────────
  savePlannerOutput(data) {
    sessionStorage.setItem("mas_planner", JSON.stringify(data));
  },

  getPlannerOutput() {
    try {
      const raw = sessionStorage.getItem("mas_planner");
      return raw ? JSON.parse(raw) : null;
    } catch(e) { return null; }
  },

  saveCoderOutputs(data) {
    sessionStorage.setItem("mas_coder", JSON.stringify(data));
  },

  getCoderOutputs() {
    try {
      const raw = sessionStorage.getItem("mas_coder");
      return raw ? JSON.parse(raw) : [];
    } catch(e) { return []; }
  },

  saveReviewerOutputs(data) {
    sessionStorage.setItem("mas_reviewer", JSON.stringify(data));
  },

  getReviewerOutputs() {
    try {
      const raw = sessionStorage.getItem("mas_reviewer");
      return raw ? JSON.parse(raw) : [];
    } catch(e) { return []; }
  },

  saveTesterOutputs(data) {
    sessionStorage.setItem("mas_tester", JSON.stringify(data));
  },

  getTesterOutputs() {
    try {
      const raw = sessionStorage.getItem("mas_tester");
      return raw ? JSON.parse(raw) : [];
    } catch(e) { return []; }
  },

  saveDebuggerOutputs(data) {
    sessionStorage.setItem("mas_debugger", JSON.stringify(data));
  },

  getDebuggerOutputs() {
    try {
      const raw = sessionStorage.getItem("mas_debugger");
      return raw ? JSON.parse(raw) : [];
    } catch(e) { return []; }
  },

  saveDocumenterOutput(data) {
    sessionStorage.setItem("mas_documenter", JSON.stringify(data));
  },

  getDocumenterOutput() {
    try {
      const raw = sessionStorage.getItem("mas_documenter");
      return raw ? JSON.parse(raw) : null;
    } catch(e) { return null; }
  },

  // ── AUDIT LOG ──────────────────────────────────────────────────────────────
  appendLog(entry) {
    const logs = this.getLogs();
    logs.push({ timestamp: new Date().toISOString(), ...entry });
    sessionStorage.setItem("mas_logs", JSON.stringify(logs));
  },

  getLogs() {
    try {
      const raw = sessionStorage.getItem("mas_logs");
      return raw ? JSON.parse(raw) : [];
    } catch(e) { return []; }
  },

  clearLogs() {
    sessionStorage.removeItem("mas_logs");
  },

  // ── CLEAR ALL ──────────────────────────────────────────────────────────────
  clearAll() {
    const groqKey   = this.getApiKey();
    const geminiKey = this.getGeminiKey();
    sessionStorage.clear();
    if (groqKey)   this.saveApiKey(groqKey);
    if (geminiKey) this.saveGeminiKey(geminiKey);
  }

};
