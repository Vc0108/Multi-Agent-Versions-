// utils/memory.js
// Agent Memory System — stores learnings across pipeline runs

const AgentMemory = {

  MAX_RUNS: 5, // keep last 5 runs in memory
  STORAGE_KEY: "agentMemory_v1",

  // ── SAVE a completed run into memory ──────────────────────────────────────
  saveRun(result) {
    const memory = this._load();
    const run = {
      id: Date.now(),
      timestamp: new Date().toISOString(),
      task: result.task?.task || "",
      language: result.task?.language || "Python",
      framework: result.task?.framework || "FastAPI",
      complexity: result.task?.complexity || "moderate",

      // What worked well
      lessons: this._extractLessons(result),

      // Spec that was generated
      spec: result.spec || null,

      // Health score from this run
      healthScore: result.healthScore || null,

      // Successful patterns detected
      patterns: this._extractPatterns(result),

      // Errors that occurred
      errors: this._extractErrors(result),
    };

    memory.runs.unshift(run); // newest first
    if (memory.runs.length > this.MAX_RUNS) memory.runs = memory.runs.slice(0, this.MAX_RUNS);
    memory.totalRuns = (memory.totalRuns || 0) + 1;
    this._save(memory);
    return run;
  },

  // ── GET context for agents based on past runs ─────────────────────────────
  getContextForAgent(agentName, currentTask) {
    const memory = this._load();
    if (!memory.runs.length) return "";

    const similar = this._findSimilarRuns(memory.runs, currentTask);
    if (!similar.length) return "";

    const lines = [`[AGENT MEMORY — ${agentName}]`];
    lines.push(`You have run ${memory.totalRuns} pipelines before. Here are relevant lessons:`);

    similar.slice(0, 3).forEach((run, i) => {
      lines.push(`\nRun ${i+1} (${run.task.substring(0,50)}...):`);
      const agentLessons = run.lessons[agentName] || [];
      agentLessons.forEach(l => lines.push(`  - ${l}`));
    });

    // Add common errors to avoid
    const commonErrors = this._getCommonErrors(memory.runs, agentName);
    if (commonErrors.length) {
      lines.push(`\nCommon errors to AVOID:`);
      commonErrors.forEach(e => lines.push(`  ⚠️ ${e}`));
    }

    return lines.join("\n");
  },

  // ── GET summary of all past runs for UI display ───────────────────────────
  getHistory() {
    const memory = this._load();
    return memory.runs.map(run => ({
      id: run.id,
      timestamp: run.timestamp,
      task: run.task,
      framework: run.framework,
      language: run.language,
      healthScore: run.healthScore,
      spec: run.spec,
    }));
  },

  // ── CLEAR all memory ──────────────────────────────────────────────────────
  clearMemory() {
    this._save({ runs: [], totalRuns: 0 });
  },

  // ── GET total runs count ──────────────────────────────────────────────────
  getTotalRuns() {
    return this._load().totalRuns || 0;
  },

  // ── PRIVATE: extract lessons from a completed result ─────────────────────
  _extractLessons(result) {
    const lessons = {
      SpecGenerator: [],
      Planner: [],
      Architect: [],
      Coder: [],
      Reviewer: [],
      Tester: [],
      Debugger: [],
      SecurityScanner: [],
      Documenter: [],
    };

    // Coder lessons from reviewer feedback
    if (result.reviewer) {
      result.reviewer.forEach(r => {
        if (r.success && r.data?.issues?.length) {
          r.data.issues.forEach(issue => {
            if (issue.severity === "high") {
              lessons.Coder.push(`Avoid: ${issue.description}`);
            }
          });
        }
        if (r.success && r.data?.strengths?.length) {
          r.data.strengths.slice(0,2).forEach(s => {
            lessons.Coder.push(`Good pattern: ${s}`);
          });
        }
      });
    }

    // Debugger lessons from failed tests
    if (result.debugger) {
      result.debugger.forEach(r => {
        if (r.success && r.data?.debug_loops > 0) {
          lessons.Debugger.push(`Fixed: ${r.data.fixes_applied?.[0] || "unknown issue"}`);
        }
      });
    }

    // Security lessons
    if (result.security) {
      (result.security.critical_issues || []).forEach(issue => {
        lessons.Coder.push(`Security: Always fix — ${issue.description}`);
      });
    }

    // Spec compliance lessons
    if (result.specCompliance) {
      const missing = result.specCompliance.missingEndpoints || [];
      if (missing.length) {
        lessons.Coder.push(`Missing endpoints in last run: ${missing.join(", ")}`);
      }
    }

    return lessons;
  },

  // ── PRIVATE: extract code patterns that worked ────────────────────────────
  _extractPatterns(result) {
    const patterns = [];
    const allCode = (result.coder || [])
      .filter(r => r.success && r.data?.code)
      .map(r => r.data.code).join("\n");

    if (/BaseModel/i.test(allCode))   patterns.push("pydantic_models");
    if (/APIRouter/i.test(allCode))   patterns.push("api_router");
    if (/try.*except/i.test(allCode)) patterns.push("error_handling");
    if (/jwt|bearer/i.test(allCode))  patterns.push("jwt_auth");
    if (/"""/.test(allCode))          patterns.push("docstrings");

    return patterns;
  },

  // ── PRIVATE: extract errors that occurred ─────────────────────────────────
  _extractErrors(result) {
    const errors = [];
    (result.audit_log || []).forEach(log => {
      if (log.status === "error" && log.error) {
        errors.push({ agent: log.agent, error: log.error.substring(0, 100) });
      }
    });
    return errors;
  },

  // ── PRIVATE: find runs similar to current task ────────────────────────────
  _findSimilarRuns(runs, currentTask) {
    const task = (currentTask || "").toLowerCase();
    return runs.filter(run => {
      const runTask = (run.task || "").toLowerCase();
      const words = task.split(" ").filter(w => w.length > 4);
      return words.some(w => runTask.includes(w));
    });
  },

  // ── PRIVATE: get common errors across runs for an agent ───────────────────
  _getCommonErrors(runs, agentName) {
    const errors = [];
    runs.forEach(run => {
      (run.errors || []).forEach(e => {
        if (e.agent === agentName) errors.push(e.error);
      });
    });
    return [...new Set(errors)].slice(0, 3);
  },

  // ── PRIVATE: load from sessionStorage ─────────────────────────────────────
  _load() {
    try {
      const raw = sessionStorage.getItem(this.STORAGE_KEY);
      return raw ? JSON.parse(raw) : { runs: [], totalRuns: 0 };
    } catch(e) {
      return { runs: [], totalRuns: 0 };
    }
  },

  // ── PRIVATE: save to sessionStorage ──────────────────────────────────────
  _save(memory) {
    try {
      sessionStorage.setItem(this.STORAGE_KEY, JSON.stringify(memory));
    } catch(e) {
      console.warn("[AgentMemory] Could not save memory:", e);
    }
  }

};
