// orchestrator/orchestrator.js
const Orchestrator = {

  name: "Orchestrator",
  icon: "🎯",

  steps: [
    { id: 1, name: "Spec Generator",   icon: "📐", status: "pending" },
    { id: 2, name: "Planner Agent",    icon: "🧭", status: "pending" },
    { id: 3, name: "Architect Agent",  icon: "🏛️", status: "pending" },
    { id: 4, name: "Coder Agent",      icon: "💻", status: "pending" },
    { id: 5, name: "Reviewer Agent",   icon: "🔍", status: "pending" },
    { id: 6, name: "Tester Agent",     icon: "🧪", status: "pending" },
    { id: 7, name: "Debugger Agent",   icon: "🔧", status: "pending" },
    { id: 8, name: "Security Scanner", icon: "🔒", status: "pending" },
    { id: 9, name: "Documenter Agent", icon: "📝", status: "pending" },
  ],

  onProgress: null,

  async run(taskInput) {
    Storage.clearAll();
    AgentEvaluator.clear();
    TaskHandoff.clear();
    this.steps.forEach(s => s.status = "pending");
    Storage.appendLog({ agent: "Orchestrator", status: "pipeline_started", task: taskInput.task });

    const result = {
      task: taskInput,
      spec: null,
      architect: null,
      planner: null,
      coder: null,
      reviewer: null,
      tester: null,
      debugger: null,
      security: null,
      documenter: null,
      specCompliance: null,
      evaluations: [],
      handoffs: [],
      audit_log: [],
      success: false
    };

    try {

      // STEP 1: SPEC GENERATOR
      this._updateStep(1, "running");
      TaskHandoff.record("User", "Spec Generator", taskInput);
      const specResult = await SpecGeneratorAgent.run(taskInput);
      result.spec = specResult.data;
      result.evaluations.push(await AgentEvaluator.evaluate("Spec Generator", result.spec, taskInput.task));
      this._updateStep(1, "done");
      await sleep(3000);

      // STEP 2: PLANNER
      this._updateStep(2, "running");
      TaskHandoff.record("Spec Generator", "Planner", result.spec);
      const plannerResult = await PlannerAgent.run(taskInput, result.spec);
      if (!plannerResult.success) throw new Error("Planner failed: " + plannerResult.error);
      result.planner = plannerResult.data;
      result.evaluations.push(await AgentEvaluator.evaluate("Planner", result.planner, taskInput.task));
      this._updateStep(2, "done");
      await sleep(3000);

      // STEP 3: ARCHITECT
      this._updateStep(3, "running");
      TaskHandoff.record("Planner", "Architect", result.planner);
      const architectResult = await ArchitectAgent.run(result.spec, result.planner, taskInput);
      result.architect = architectResult.data;
      result.evaluations.push(await AgentEvaluator.evaluate("Architect", result.architect, taskInput.task));
      this._updateStep(3, "done");
      await sleep(3000);

      // STEP 4: CODER
      this._updateStep(4, "running");
      TaskHandoff.record("Architect", "Coder", result.architect);
      const coderResult = await CoderAgent.run(result.planner, taskInput, result.spec, result.architect);
      if (!coderResult.success) throw new Error("Coder failed: " + coderResult.error);
      result.coder = coderResult.data;
      const coderEval = await AgentEvaluator.evaluate("Coder", (result.coder[0]&&result.coder[0].data)||{}, taskInput.task);
      result.evaluations.push(coderEval);
      this._updateStep(4, "done");
      await sleep(3000);

      // STEP 5: REVIEWER
      this._updateStep(5, "running");
      TaskHandoff.record("Coder", "Reviewer", result.coder);
      const reviewerResult = await ReviewerAgent.run(coderResult.data, plannerResult.data, taskInput, result.spec);
      if (!reviewerResult.success) throw new Error("Reviewer failed: " + reviewerResult.error);
      result.reviewer = reviewerResult.data;
      const reviewerEval = await AgentEvaluator.evaluate("Reviewer", (result.reviewer[0]&&result.reviewer[0].data)||{}, taskInput.task);
      result.evaluations.push(reviewerEval);
      this._updateStep(5, "done");
      await sleep(3000);

      // STEP 6: TESTER
      this._updateStep(6, "running");
      TaskHandoff.record("Reviewer", "Tester", result.reviewer);
      const testerResult = await TesterAgent.run(reviewerResult.data, taskInput);
      if (!testerResult.success) throw new Error("Tester failed: " + testerResult.error);
      result.tester = testerResult.data;
      const testerEval = await AgentEvaluator.evaluate("Tester", (result.tester[0]&&result.tester[0].data)||{}, taskInput.task);
      result.evaluations.push(testerEval);
      this._updateStep(6, "done");
      await sleep(3000);

      // STEP 7: DEBUGGER
      const needsDebug = testerResult.data.some(r => r.data && r.data.needs_debug);
      this._updateStep(7, needsDebug ? "running" : "skipped");
      TaskHandoff.record("Tester", "Debugger", result.tester);
      const debuggerResult = await DebuggerAgent.run(testerResult.data, taskInput);
      result.debugger = debuggerResult.data;
      if (needsDebug && result.debugger && result.debugger.length) {
        const debugEval = await AgentEvaluator.evaluate("Debugger", (result.debugger[0]&&result.debugger[0].data)||{}, taskInput.task);
        result.evaluations.push(debugEval);
      }
      this._updateStep(7, "done");
      await sleep(3000);

      // STEP 8: SECURITY SCANNER
      this._updateStep(8, "running");
      const codeForScan = (debuggerResult.data && debuggerResult.data.length > 0)
        ? debuggerResult.data : testerResult.data;
      TaskHandoff.record("Debugger", "Security Scanner", codeForScan);
      const securityResult = await SecurityScannerAgent.run(codeForScan, taskInput);
      result.security = securityResult.data;
      result.evaluations.push(await AgentEvaluator.evaluate("Security Scanner", result.security, taskInput.task));
      this._updateStep(8, "done");
      await sleep(3000);

      // STEP 9: DOCUMENTER
      this._updateStep(9, "running");
      const docInput = (debuggerResult.data && debuggerResult.data.length > 0)
        ? debuggerResult.data : testerResult.data;
      TaskHandoff.record("Security Scanner", "Documenter", result.security);
      const documenterResult = await DocumenterAgent.run(docInput, plannerResult.data, taskInput, result.spec);
      if (!documenterResult.success) throw new Error("Documenter failed: " + documenterResult.error);
      result.documenter = documenterResult.data;
      result.evaluations.push(await AgentEvaluator.evaluate("Documenter", result.documenter, taskInput.task));
      this._updateStep(9, "done");

      // SPEC COMPLIANCE CHECK (local, no AI)
      const allCode = (result.coder || [])
        .filter(r => r.success && r.data && r.data.code)
        .map(r => r.data.code).join("\n");
      result.specCompliance = ContextBuilder.specValidator(result.spec, allCode);

      // SAVE TO MEMORY
      try { AgentMemory.saveRun(result); } catch(e) {}

      result.handoffs = TaskHandoff.getChain();
      result.audit_log = Storage.getLogs();
      result.success = true;
      Storage.appendLog({ agent: "Orchestrator", status: "pipeline_completed" });
      return result;

    } catch (error) {
      Storage.appendLog({ agent: "Orchestrator", status: "pipeline_error", error: error.message });
      result.audit_log = Storage.getLogs();
      result.error = error.message;
      return result;
    }
  },

  async rerunAgent(agentName, result) {
    Storage.appendLog({ agent: "Orchestrator", status: "rerun_started", agentName });
    try {
      if (agentName === "Spec Generator") {
        this._updateStep(1, "running");
        const r = await SpecGeneratorAgent.run(result.task);
        result.spec = r.data;
        this._updateStep(1, "done");

      } else if (agentName === "Planner") {
        this._updateStep(2, "running");
        const r = await PlannerAgent.run(result.task, result.spec);
        if (r.success) result.planner = r.data;
        this._updateStep(2, r.success ? "done" : "error");

      } else if (agentName === "Architect") {
        this._updateStep(3, "running");
        const r = await ArchitectAgent.run(result.spec, result.planner, result.task);
        result.architect = r.data;
        this._updateStep(3, "done");

      } else if (agentName === "Coder") {
        this._updateStep(4, "running");
        const r = await CoderAgent.run(result.planner, result.task, result.spec, result.architect);
        if (r.success) result.coder = r.data;
        this._updateStep(4, r.success ? "done" : "error");

      } else if (agentName === "Reviewer") {
        this._updateStep(5, "running");
        const r = await ReviewerAgent.run(result.coder, result.planner, result.task, result.spec);
        if (r.success) result.reviewer = r.data;
        this._updateStep(5, r.success ? "done" : "error");

      } else if (agentName === "Tester") {
        this._updateStep(6, "running");
        const r = await TesterAgent.run(result.reviewer, result.task);
        if (r.success) result.tester = r.data;
        this._updateStep(6, r.success ? "done" : "error");

      } else if (agentName === "Debugger") {
        this._updateStep(7, "running");
        const r = await DebuggerAgent.run(result.tester, result.task);
        result.debugger = r.data;
        this._updateStep(7, "done");

      } else if (agentName === "Security Scanner") {
        this._updateStep(8, "running");
        const src = (result.debugger && result.debugger.length) ? result.debugger : result.tester;
        const r = await SecurityScannerAgent.run(src, result.task);
        result.security = r.data;
        this._updateStep(8, "done");

      } else if (agentName === "Documenter") {
        this._updateStep(9, "running");
        const src = (result.debugger && result.debugger.length) ? result.debugger : result.tester;
        const r = await DocumenterAgent.run(src, result.planner, result.task, result.spec);
        if (r.success) result.documenter = r.data;
        this._updateStep(9, r.success ? "done" : "error");
      }

      // Recompute spec compliance
      const allCode = (result.coder || []).filter(r => r.success && r.data && r.data.code).map(r => r.data.code).join("\n");
      result.specCompliance = ContextBuilder.specValidator(result.spec, allCode);
      return result;
    } catch(err) {
      Storage.appendLog({ agent: "Orchestrator", status: "rerun_error", agentName, error: err.message });
      throw err;
    }
  },

  exportOutput(result) {
    const finalCode = (result.debugger || result.tester || [])
      .filter(r => r.success && r.data && r.data.final_code)
      .map(r => "// === " + r.data.subtask_name + " ===\n\n" + r.data.final_code)
      .join("\n\n\n");
    const readme = result.documenter && result.documenter.readme ? result.documenter.readme : "# Project\nNo docs generated.";
    const auditLog = JSON.stringify(result.audit_log, null, 2);
    return { finalCode, readme, auditLog };
  },

  _updateStep(stepId, status, data) {
    const step = this.steps.find(s => s.id === stepId);
    if (step) step.status = status;
    if (this.onProgress) this.onProgress(stepId, status, data);
  }

};
