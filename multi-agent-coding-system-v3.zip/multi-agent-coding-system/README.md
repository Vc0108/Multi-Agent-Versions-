# 🤖 Multi-Agent Collaborative Coding System

> Context Engineering for Code Generation — Powered by Groq + LLaMA 3.3 70B

---

## 📋 Overview

A multi-agent AI system where 6 specialized agents collaborate to take a plain English task description and produce a fully reviewed, tested, and documented codebase — automatically.

## 🏗️ Architecture

```
User Input
    ↓
🎯 Orchestrator (manages pipeline)
    ↓
🧭 Planner Agent   → Breaks task into subtasks
    ↓
💻 Coder Agent     → Writes code for each subtask
    ↓
🔍 Reviewer Agent  → Reviews for bugs & security (loops back if FAIL)
    ↓
🧪 Tester Agent    → Writes & runs tests (routes to Debugger if FAIL)
    ↓
🔧 Debugger Agent  → Fixes failing tests (loops with Tester)
    ↓
📝 Documenter Agent → Generates README, API docs, setup guide
    ↓
✅ Final Output
```

## 📁 Project Structure

```
multi-agent-coding-system/
├── index.html                  ← Main UI (open this in browser)
├── styles/
│   └── main.css               ← Global styles
├── agents/
│   ├── planner.js             ← Planner Agent
│   ├── coder.js               ← Coder Agent
│   ├── reviewer.js            ← Reviewer Agent
│   ├── tester.js              ← Tester Agent
│   ├── debugger.js            ← Debugger Agent
│   └── documenter.js          ← Documenter Agent
├── orchestrator/
│   └── orchestrator.js        ← Pipeline controller
├── utils/
│   ├── api.js                 ← Groq API helper
│   ├── context.js             ← Context engineering prompts
│   └── storage.js             ← Session state management
└── README.md
```

## 🚀 Getting Started

### 1. Get a Free Groq API Key
- Go to [console.groq.com](https://console.groq.com)
- Sign up (free — no credit card needed)
- Create an API Key → copy it

### 2. Open the App
- Open `index.html` in your browser (or use Live Server in VS Code)
- Paste your Groq API key in the top-left input → click Save

### 3. Run the Pipeline
- Enter your task description
- Select Language, Framework, Database
- Click **Run All Agents**
- Watch all 6 agents work in real time!

## ⚙️ Context Engineering Techniques Used

| Agent | Techniques |
|-------|-----------|
| Planner | Intent-First, Hierarchical Context, Structured Formatting |
| Coder | Dependency-Aware, Anchor Context, Few-Shot |
| Reviewer | Anchor Context, Metadata Enrichment, Feedback Loop |
| Tester | Test-Driven Context, Iterative Refinement |
| Debugger | Feedback Loop, History Management, Iterative Refinement |
| Documenter | Metadata Enrichment, Hierarchical Context |

## 🛠️ Tech Stack

- **Frontend:** Vanilla HTML, CSS, JavaScript
- **AI Model:** LLaMA 3.3 70B via Groq API
- **No backend required** — runs entirely in the browser

## 📤 Exports

After a pipeline run you can download:
- `generated_code.js` — All reviewed & tested code
- `tests.js` — Complete test suite
- `README.md` — Generated documentation
- `audit_log.json` — Full agent decision log

## 🔒 Security

- API key is stored in `sessionStorage` only (cleared when tab closes)
- No data is sent anywhere except directly to Groq API
- All processing happens client-side

---

Built as an internship project demonstrating **Context Engineering for Code Generation**.
